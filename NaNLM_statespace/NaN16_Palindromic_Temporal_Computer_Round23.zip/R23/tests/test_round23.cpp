#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 23: Modal logic (Kripke) ===\n\n";

    std::cout << "── Duality ◇P ↔ ¬□¬P ──\n";
    {
        Topology t;
        t.modal_clear();
        t.modal_set_worlds(3);
        t.modal_access(0, 1); t.modal_access(1, 2); t.modal_access(2, 0);
        t.modal_val(0, 0, true);
        t.modal_val(1, 0, false);
        t.modal_val(2, 0, true);
        check(t.modal_duality(0), "duality holds on cycle frame");
    }

    std::cout << "\n── Distribution axiom K ──\n";
    {
        Topology t;
        t.modal_clear();
        t.modal_set_worlds(3);
        t.modal_access(0, 0); t.modal_access(0, 1); t.modal_access(1, 2);
        t.modal_val(0, 0, true); t.modal_val(1, 0, true); t.modal_val(2, 0, false);
        t.modal_val(0, 1, true); t.modal_val(1, 1, false); t.modal_val(2, 1, false);
        check(t.modal_axiom_K(0, 1), "□(P→Q) → (□P → □Q) on all frames");
    }

    std::cout << "\n── Reflexivity / axiom T ──\n";
    {
        Topology t;
        t.modal_clear();
        t.modal_set_worlds(2);
        t.modal_access(0, 1); // not reflexive
        t.modal_val(0, 0, false);
        t.modal_val(1, 0, true);
        check(!t.modal_axiom_T(0), "T fails without reflexivity (□P true, P false)");
        t.modal_make_reflexive();
        check(t.modal_axiom_T(0), "T holds after making reflexive");
    }

    std::cout << "\n── Transitivity / axiom 4 ──\n";
    {
        Topology t;
        t.modal_clear();
        t.modal_set_worlds(3);
        t.modal_access(0, 1); t.modal_access(1, 2);
        t.modal_make_reflexive();
        t.modal_make_transitive();
        t.modal_val(0, 0, true); t.modal_val(1, 0, true); t.modal_val(2, 0, true);
        check(t.modal_axiom_4(0), "□P → □□P on transitive frame");
        check(t.modal_eval_box(0, 0), "□P at root");
    }

    std::cout << "\n── Possibility vs necessity ──\n";
    {
        Topology t;
        t.modal_clear();
        t.modal_set_worlds(2);
        t.modal_access(0, 0);
        t.modal_access(0, 1);
        t.modal_val(0, 3, false);
        t.modal_val(1, 3, true);
        check(t.modal_eval_diamond(0, 3), "◇P when some neighbor has P");
        check(!t.modal_eval_box(0, 3), "not □P when some accessible world lacks P");
    }

    std::cout << "\n── Symmetry / axiom B ──\n";
    {
        Topology t;
        t.modal_clear();
        t.modal_set_worlds(2);
        t.modal_access(0, 1);
        t.modal_make_symmetric();
        t.modal_make_reflexive();
        t.modal_val(0, 0, true);
        t.modal_val(1, 0, true);
        check(t.modal_axiom_B(0), "P → □◇P on symmetric frame");
    }

    std::cout << "\n── Epistemic knowledge K_a ──\n";
    {
        Topology t;
        t.modal_clear();
        t.modal_set_worlds(2);
        t.modal_val(0, 5, true);
        t.modal_val(1, 5, false);
        t.modal_agent_access(0, 0, 0);
        t.modal_agent_access(0, 0, 1);
        check(!t.modal_knows(0, 0, 5), "agent does not know P when worlds disagree");
        t.modal_val(1, 5, true);
        check(t.modal_knows(0, 0, 5), "agent knows P when true in all indistinguishable worlds");
    }

    std::cout << "\n── Modal suite ──\n";
    {
        Topology t;
        auto S = t.experiment_modal_suite();
        std::printf("  %d/%d dual=%d K=%d T=%d 4=%d B=%d epi=%d\n",
            S.passed, S.tests, (int)S.dual,(int)S.K,(int)S.T,(int)S.four,
            (int)S.B,(int)S.epistemic);
        check(S.passed == S.tests, "MODAL SUITE GREEN");
    }

    std::cout << "\n── R22 puzzle regression ──\n";
    {
        Topology t;
        auto S = t.experiment_hard_puzzles();
        check(S.passed == S.tests, "R22 puzzles still green");
    }

    std::cout << "\n========================================\n"
              << "Round 23: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
