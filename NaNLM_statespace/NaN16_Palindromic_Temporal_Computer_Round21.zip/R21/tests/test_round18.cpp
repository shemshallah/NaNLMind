#include "nan16_ptc.hpp"
#include <sys/stat.h>
#include <cstdio>
#include <iostream>
#include <cmath>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 18: Resonance wave matrix + deep cognition ===\n\n";

    // --- Wave matrix structure ---
    std::cout << "--- 256-node resonance matrix ---\n";
    {
        Topology t;
        t.resonance_init();
        bool sym = true;
        float maxc = 0, minc = 1;
        for (int i = 0; i < 256; ++i)
            for (int j = 0; j < 256; ++j) {
                float c = t.resonance_coupling(i, j);
                if (i != j) {
                    if (std::fabs(c - t.resonance_coupling(j, i)) > 1e-5f) sym = false;
                    if (c > maxc) maxc = c;
                    if (c < minc) minc = c;
                } else if (c != 0.f) sym = false;
            }
        std::printf("  symmetric=%d coupling range [%.4f, %.4f]\n", (int)sym, minc, maxc);
        check(sym, "coupling matrix symmetric, zero diagonal");
        check(maxc > 0.5f && minc < 0.1f, "local strong / long-range weak falloff");
    }

    // --- Wave propagation ---
    std::cout << "\n--- Resonant wave propagation ---\n";
    {
        Topology t;
        int steps = t.resonance_propagate(0, 15, 0.02f, 500);
        std::printf("  0 → 15 in %d steps, E15=%.4f\n", steps, t.resonance(15).energy);
        check(steps > 0, "energy reaches lattice neighbor path");
        int far = t.resonance_propagate(0, 255, 0.02f, 800);
        std::printf("  0 → 255 in %d steps, E255=%.4f\n", far, t.resonance(255).energy);
        check(far > 0, "energy reaches opposite corner of 16×16 free-bit lattice");
    }

    // --- Coherence ---
    std::cout << "\n--- Phase coherence ---\n";
    {
        Topology t;
        t.resonance_init();
        t.resonance_ping(8, 1.2f, 0.0f);
        t.resonance_ping(9, 1.2f, 0.05f);
        t.resonance_ping(24, 1.0f, 0.02f);
        float c0 = t.resonance_coherence(12);
        for (int i = 0; i < 40; ++i) t.resonance_wave_step(0.1f);
        float c1 = t.resonance_coherence(12);
        std::printf("  coherence %.3f → %.3f\n", c0, c1);
        check(c1 > c0 - 0.5f, "coherence measurable after wave evolution");
    }

    // --- Learning speed ---
    std::cout << "\n--- Learning speed ---\n";
    {
        Topology t;
        auto L = t.experiment_learning_speed(30);
        std::printf("  learned=%d exposures=%d hops=%d time=%.6fs\n",
            (int)L.learned, L.exposures, L.hops_ok, L.seconds);
        check(L.learned, "3-hop chain learned");
        check(L.exposures <= 3, "learns within 3 exposures (symbolic assert is fast)");
    }

    // --- Context capacity ---
    std::cout << "\n--- Context capacity ---\n";
    {
        Topology t;
        auto C = t.experiment_context_capacity(500);
        std::printf("  facts=%d accuracy=%.3f capacity@95%%=%d\n",
            C.facts_loaded, C.accuracy, C.capacity_at_95);
        check(C.capacity_at_95 >= 100, "≥100 facts at ≥95% probe accuracy");
        check(C.accuracy >= 0.95, "final accuracy still high (exact KB)");
    }

    // --- Multi-hop ---
    std::cout << "\n--- Multi-hop cognitive depth ---\n";
    {
        Topology t;
        auto H = t.experiment_multihop_reasoning();
        std::printf("  d1=%d d2=%d d3=%d d4=%d max=%d\n",
            (int)H.depth1,(int)H.depth2,(int)H.depth3,(int)H.depth4, H.max_depth_ok);
        check(H.depth1 && H.depth2 && H.depth3, "depths 1–3 OK");
        check(H.depth4, "depth-4 exception inheritance (unknown→penguin→¬fly)");
    }

    // --- Resonant recall ---
    std::cout << "\n--- Resonant recall ---\n";
    {
        Topology t;
        auto R = t.experiment_resonant_recall();
        std::printf("  steps=%d energy=%.4f reached=%d\n", R.steps, R.final_energy, (int)R.reached);
        check(R.reached, "concept-mapped heads resonate across matrix");
    }

    // --- Full deep suite ---
    std::cout << "\n--- Deep cognition suite ---\n";
    {
        Topology t;
        auto S = t.experiment_deep_cognition();
        std::printf("  %d/%d wave=%d learn_exp=%d ctx95=%d hops=%d\n",
            S.passed, S.tests, (int)S.wave_matrix_ok, S.learn.exposures,
            S.ctx.capacity_at_95, S.hops.max_depth_ok);
        check(S.passed == S.tests, "deep cognition suite all green");
    }

    // --- R17 regression ---
    std::cout << "\n--- R17 continuity regression ---\n";
    {
        Topology t;
        mkdir("/tmp/nan16_r18_reg", 0755);
        auto S = t.experiment_continuity_suite("/tmp/nan16_r18_reg");
        check(S.passed == S.tests, "R17 continuity still green");
    }

    std::cout << "\n========================================\n"
              << "Round 18: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
