#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 14: NaN16 Cognitive Architecture ===\n\n";

    // --- Knowledge graph setup ---
    std::cout << "--- Associative memory / knowledge graph ---\n";
    {
        Topology t;
        t.cog_clear();
        t.cog_assert(Topology::C_EAGLE, Topology::R_ISA, Topology::C_BIRD);
        t.cog_assert(Topology::C_PENGUIN, Topology::R_ISA, Topology::C_BIRD);
        t.cog_assert(Topology::C_BIRD, Topology::R_HAS, Topology::C_WINGS);
        t.cog_assert(Topology::C_EAGLE, Topology::R_CAN, Topology::C_FLY);
        t.cog_assert(Topology::C_PENGUIN, Topology::R_CANNOT, Topology::C_FLY);
        t.cog_assert(Topology::C_BIRD, Topology::R_CAN, Topology::C_FLY);
        check(t.cog_triple_count() == 6, "6 triples stored in topology");

        auto wings = t.cog_associate(Topology::C_BIRD, Topology::R_HAS);
        bool hw = false;
        for (int i = 0; i < wings.n; ++i) if (wings.objects[i] == Topology::C_WINGS) hw = true;
        check(hw, "associate(bird, HAS) → wings");

        auto ew = t.cog_associate(Topology::C_EAGLE, Topology::R_HAS);
        bool ehw = false;
        for (int i = 0; i < ew.n; ++i) if (ew.objects[i] == Topology::C_WINGS) ehw = true;
        check(ehw, "associate(eagle, HAS) inherits wings");
    }

    // --- Core questions ---
    std::cout << "\n--- Core questions ---\n";
    {
        Topology t;
        t.cog_clear();
        t.cog_assert(Topology::C_EAGLE, Topology::R_ISA, Topology::C_BIRD);
        t.cog_assert(Topology::C_PENGUIN, Topology::R_ISA, Topology::C_BIRD);
        t.cog_assert(Topology::C_BIRD, Topology::R_HAS, Topology::C_WINGS);
        t.cog_assert(Topology::C_EAGLE, Topology::R_CAN, Topology::C_FLY);
        t.cog_assert(Topology::C_PENGUIN, Topology::R_CANNOT, Topology::C_FLY);
        t.cog_assert(Topology::C_BIRD, Topology::R_CAN, Topology::C_FLY);

        auto p = t.cog_query(Topology::C_PENGUIN, Topology::R_CAN, Topology::C_FLY, true);
        std::printf("  Can penguins fly? yes=%d found=%d exc=%d contrad=%d\n",
            (int)p.yes,(int)p.found,(int)p.used_exception,(int)p.contradiction);
        check(p.found && !p.yes && p.used_exception, "penguins cannot fly (exception wins)");

        auto e = t.cog_query(Topology::C_EAGLE, Topology::R_CAN, Topology::C_FLY, true);
        check(e.found && e.yes, "eagles can fly");

        t.cog_assert(Topology::C_UNKNOWN, Topology::R_ISA, Topology::C_PENGUIN);
        auto u = t.cog_query(Topology::C_UNKNOWN, Topology::R_CAN, Topology::C_FLY, true);
        std::printf("  Unknown-as-penguin fly? yes=%d found=%d exc=%d\n",
            (int)u.yes,(int)u.found,(int)u.used_exception);
        check(u.found && !u.yes && u.used_exception, "unknown penguin-class → cannot fly");
    }

    // --- Dual inference ---
    std::cout << "\n--- Dual inference (general vs exception) ---\n";
    {
        Topology t;
        t.cog_clear();
        t.cog_assert(Topology::C_PENGUIN, Topology::R_ISA, Topology::C_BIRD);
        t.cog_assert(Topology::C_BIRD, Topology::R_CAN, Topology::C_FLY);
        t.cog_assert(Topology::C_PENGUIN, Topology::R_CANNOT, Topology::C_FLY);
        auto d = t.cog_dual_inference(Topology::C_PENGUIN, Topology::R_CAN, Topology::C_FLY);
        std::printf("  general_yes=%d dual_yes=%d disagreed=%d\n",
            (int)d.general_only.yes,(int)d.with_exceptions.yes,(int)d.disagreed);
        check(d.disagreed, "general and exception paths disagree");
        check(d.with_exceptions.yes == false, "dual resolution: cannot fly");
    }

    // --- Counterfactual ---
    std::cout << "\n--- Counterfactual reasoning ---\n";
    {
        Topology t;
        t.cog_clear();
        t.cog_assert(Topology::C_PENGUIN, Topology::R_ISA, Topology::C_BIRD);
        t.cog_assert(Topology::C_BIRD, Topology::R_CAN, Topology::C_FLY);
        t.cog_assert(Topology::C_PENGUIN, Topology::R_CANNOT, Topology::C_FLY);
        // Manual counterfactual in suite style verified by suite; use API
        auto cf = t.cog_counterfactual(
            Topology::C_PENGUIN, Topology::R_CAN, Topology::C_FLY,
            Topology::C_PENGUIN, Topology::R_CAN, Topology::C_FLY,  // hyp assert CAN (exception still present)
            Topology::C_PENGUIN, Topology::R_CAN, Topology::C_FLY);
        // With exception still present, hyp CAN may not flip; suite has stronger test
        check(cf.restored, "counterfactual restores original state");
    }

    // --- Continual learning ---
    std::cout << "\n--- Continual learning ---\n";
    {
        Topology t;
        t.cog_clear();
        t.cog_assert(Topology::C_EAGLE, Topology::R_ISA, Topology::C_BIRD);
        t.cog_assert(Topology::C_EAGLE, Topology::R_CANNOT, Topology::C_FLY); // wrong belief
        auto before = t.cog_query(Topology::C_EAGLE, Topology::R_CAN, Topology::C_FLY, true);
        check(before.yes == false, "before feedback: eagle cannot fly (wrong)");
        auto L = t.cog_learn_feedback(Topology::C_EAGLE, Topology::R_CAN, Topology::C_FLY, true);
        std::printf("  after learn: yes=%d improved=%d\n", (int)L.after.yes, (int)L.improved);
        check(L.after.yes && L.improved, "feedback corrects eagle→can fly");
    }

    // --- Distributed pages ---
    std::cout << "\n--- Distributed cognition ---\n";
    {
        Topology t;
        auto d = t.cog_distributed_query();
        check(d.ok, "portal carries exception; page1 answers correctly");
    }

    // --- Full suite ---
    std::cout << "\n--- Cognitive suite ---\n";
    {
        Topology t;
        auto S = t.experiment_cognitive_suite();
        std::printf("  %d/%d  penguin=%d eagle=%d unknown=%d dual=%d cf=%d learn=%d dist=%d\n",
            S.passed, S.tests, (int)S.penguin_fly_ok, (int)S.eagle_fly_ok,
            (int)S.unknown_penguin_ok, (int)S.dual_ok, (int)S.counterfactual_ok,
            (int)S.learn_ok, (int)S.distributed_ok);
        check(S.passed == S.tests, "all suite tests pass");
        check(S.penguin_fly_ok && S.eagle_fly_ok && S.unknown_penguin_ok, "core bird graph");
        check(S.dual_ok && S.counterfactual_ok && S.learn_ok, "dual + CF + learn");
        check(S.distributed_ok, "distributed");
    }

    // --- R13 regression ---
    std::cout << "\n--- R13 regression ---\n";
    {
        Topology t;
        auto m = t.experiment_twocm_mul(0xE000, 3, 4);
        check(m.ok && m.out == 12, "R13 2CM mul still works");
    }

    std::cout << "\n========================================\n"
              << "Round 14: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
