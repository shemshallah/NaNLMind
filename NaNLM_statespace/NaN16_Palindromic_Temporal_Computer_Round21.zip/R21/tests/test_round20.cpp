#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 20: EXTREME cognitive battery ===\n\n";

    // 1 Diamond
    std::cout << "┌─ Diamond inheritance (conflicting paths) ─────────\n";
    {
        Topology t;
        auto D = t.experiment_diamond_inheritance();
        std::printf("│  B can fly: %s\n", D.path_b ? "YES" : "NO");
        std::printf("│  C can fly: %s (expect NO)\n", D.path_c ? "blocked" : "FAIL");
        std::printf("│  D (child of both) conflict handled: %s\n",
            D.conflict_visible ? "YES" : "NO");
        check(D.path_b && D.path_c && D.conflict_visible,
              "diamond: B yes, C no, D contested/blocked");
    }

    // 2 Cycle
    std::cout << "\n┌─ ISA cycle termination ───────────────────────────\n";
    {
        Topology t;
        auto C = t.experiment_isa_cycle();
        std::printf("│  terminates: %s  steps=%d\n", C.terminates?"YES":"NO", C.steps);
        check(C.terminates && C.steps < 10000, "cyclic ISA does not hang");
    }

    // 3 Revision
    std::cout << "\n┌─ Knowledge revision (assert → retract → relearn) ─\n";
    {
        Topology t;
        auto R = t.experiment_knowledge_revision();
        std::printf("│  before: %s  after retract: %s  relearn: %s\n",
            R.before_yes?"YES":"NO",
            R.after_retract_gone?"GONE":"STILL THERE",
            R.relearn_ok?"YES":"NO");
        check(R.before_yes && R.after_retract_gone && R.relearn_ok, "revision cycle");
    }

    // 4 Exception ladder
    std::cout << "\n┌─ Exception ladder (10 levels) ────────────────────\n";
    {
        Topology t;
        auto L = t.experiment_exception_ladder(10);
        std::printf("│  correct %d/%d\n", L.correct, L.levels);
        check(L.all_correct, "every level blocked by exception path");
    }

    // 5 Concurrent
    std::cout << "\n┌─ Concurrent assert/query consistency ─────────────\n";
    {
        Topology t;
        auto C = t.experiment_concurrent_consistency(200);
        std::printf("│  consistent %d/%d queries\n", C.consistent, C.queries);
        check(C.ok, "interleaved assert+query always consistent");
    }

    // 6 Cross-domain
    std::cout << "\n┌─ Cross-domain isolation (animals vs vehicles) ────\n";
    {
        Topology t;
        auto X = t.experiment_cross_domain_isolation();
        std::printf("│  eagle flies: %s  car has wheels: %s  no leak: %s\n",
            X.animal_ok?"Y":"N", X.vehicle_ok?"Y":"N", X.no_leak?"Y":"N");
        check(X.all_ok, "domains isolated; no wheel leakage to birds");
    }

    // 7 Specificity
    std::cout << "\n┌─ Specificity (exception overrides default) ───────\n";
    {
        Topology t;
        auto S = t.experiment_specificity();
        std::printf("│  before exception inherits: %s  after: specific wins: %s\n",
            S.general_alone_yes?"YES":"NO", S.specific_wins?"YES":"NO");
        check(S.general_alone_yes && S.specific_wins, "specificity order");
    }

    // 8 Stress path
    std::cout << "\n┌─ Stress path (10 hops, 3 exceptions) ─────────────\n";
    {
        Topology t;
        auto S = t.experiment_stress_path();
        std::printf("│  hops=%d final blocked by nearer exception: %s\n",
            S.hops, S.final_correct?"YES":"NO");
        check(S.final_correct, "nearest exception wins on long path");
    }

    // Full suite
    std::cout << "\n┌─ Extreme suite ───────────────────────────────────\n";
    {
        Topology t;
        auto S = t.experiment_extreme_cognition();
        std::printf("│  %d/%d passed\n", S.passed, S.tests);
        check(S.passed == S.tests, "EXTREME COGNITION BATTERY GREEN");
    }

    // Prior hard suite still works
    std::cout << "\n┌─ R19 hard regression ─────────────────────────────\n";
    {
        Topology t;
        auto S = t.experiment_hard_cognition();
        std::printf("│  %d/%d\n", S.passed, S.tests);
        check(S.passed == S.tests, "R19 hard suite still green");
    }

    std::cout << "\n========================================\n"
              << "Round 20: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
