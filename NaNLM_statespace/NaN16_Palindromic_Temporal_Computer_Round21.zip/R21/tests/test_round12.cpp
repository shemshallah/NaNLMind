#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
#include <vector>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

static std::uint32_t OP(std::uint8_t o) { return o; }
static std::uint32_t IMM(std::uint32_t v) { return v; }

int main() {
    std::cout << "=== Round 12: Program-in-State VM (NaN16 Computer) ===\n";
    std::cout << "Program, IP, regs, flags in topology. One RuleVmCycle. Host seeds & steps only.\n\n";

    // --- Brief programs ---
    std::cout << "--- Research-brief programs ---\n";
    {
        Topology t;
        // LOAD A,13; LOAD B,7; XOR; ADD 4; OUT; HALT → 14
        std::uint32_t p1[] = {
            OP(Topology::VmLoadA),IMM(13),OP(Topology::VmLoadB),IMM(7),OP(Topology::VmXor),
            OP(Topology::VmAddImm),IMM(4),OP(Topology::VmOut),OP(Topology::VmHalt)
        };
        t.vm_load(0x1000, p1, 9);
        auto r1 = t.vm_run(0x1000);
        std::printf("  prog1 XOR+ADD4 => out=%u cycles=%u halt=%d\n", r1.out, r1.cycles, (int)r1.halted);
        check(r1.halted && r1.out==14, "brief prog1: (13^7)+4 = 14");

        // LOAD A,13; LOAD B,7; ADD; SUB 3; XOR 2; OUT; HALT → 19
        std::uint32_t p2[] = {
            OP(Topology::VmLoadA),IMM(13),OP(Topology::VmLoadB),IMM(7),OP(Topology::VmAdd),
            OP(Topology::VmLoadB),IMM(3),OP(Topology::VmSub),
            OP(Topology::VmLoadB),IMM(2),OP(Topology::VmXor),
            OP(Topology::VmOut),OP(Topology::VmHalt)
        };
        t.vm_load(0x1100, p2, 13);
        auto r2 = t.vm_run(0x1100);
        std::printf("  prog2 ADD/SUB/XOR => out=%u cycles=%u\n", r2.out, r2.cycles);
        check(r2.halted && r2.out==19, "brief prog2: ((13+7)-3)^2 = 19");
    }

    // --- Full suite ---
    std::cout << "\n--- VM suite (>=10 programs, branches, dual region) ---\n";
    {
        Topology t;
        auto s = t.experiment_vm_suite();
        std::printf("  programs=%u passed=%u dual=%d long=%d\n",
            s.programs, s.passed, (int)s.dual_region_ok, (int)s.long_prog_ok);
        check(s.programs >= 10, "at least 10 distinct programs");
        check(s.passed == s.programs, "all suite programs halt with expected OUT");
        check(s.dual_region_ok, "two independent VMs concurrent (XOR=10, ADD=20)");
        check(s.long_prog_ok, "long/branchy programs ok");
    }

    // --- Branching stress ---
    std::cout << "\n--- Branching / loops ---\n";
    {
        Topology t;
        // Count to N
        for (std::uint32_t n : {1u, 3u, 7u, 10u}) {
            // 0 LA,1 0, 2 LB,3 n, 4 CMP, 5 JZ, 6 12, 7 ADDIMM, 8 1, 9 JMP, 10 4, 11 NOP, 12 OUT, 13 HALT
            std::uint32_t code[] = {
                OP(Topology::VmLoadA),IMM(0),OP(Topology::VmLoadB),IMM(n),
                OP(Topology::VmCmp),OP(Topology::VmJz),IMM(12),
                OP(Topology::VmAddImm),IMM(1),
                OP(Topology::VmJmp),IMM(4),
                OP(Topology::VmNop),
                OP(Topology::VmOut),OP(Topology::VmHalt)
            };
            t.vm_load(0x2000, code, 14);
            auto r = t.vm_run(0x2000, 10000);
            bool ok = r.halted && r.out == n;
            std::printf("  count_to_%u => %u cycles=%u %s\n", n, r.out, r.cycles, ok?"OK":"BAD");
            check(ok, "count loop");
        }
    }

    // --- Schedule interleaving does not corrupt single machine ---
    std::cout << "\n--- Determinism ---\n";
    {
        Topology t1, t2;
        std::uint32_t code[] = {
            OP(Topology::VmLoadA),IMM(13),OP(Topology::VmLoadB),IMM(7),OP(Topology::VmXor),OP(Topology::VmOut),OP(Topology::VmHalt)
        };
        t1.vm_load(0x3000, code, 7);
        t2.vm_load(0x3000, code, 7);
        auto a = t1.vm_run(0x3000);
        // step-by-step
        while (t2.vm_step(0x3000)) {}
        auto b_out = t2.at_address(0x3000 + Topology::VmRegOUT).state;
        check(a.out == 10 && b_out == 10, "run vs step-loop identical");
    }

    // --- All machine cells use RuleVmCycle ---
    std::cout << "\n--- Immutable rule map ---\n";
    {
        Topology t;
        std::uint32_t code[] = {OP(Topology::VmLoadA),IMM(1),OP(Topology::VmOut),OP(Topology::VmHalt)};
        t.vm_load(0x4000, code, 4);
        t.vm_run(0x4000);
        bool all = true;
        for (int i = 0; i < 20; ++i)
            if (t.at_address(0x4000 + i).rule_id != RuleVmCycle) all = false;
        check(all, "all machine cells remain RuleVmCycle");
    }

    // --- Regression R11 ---
    std::cout << "\n--- Regression ---\n";
    {
        Topology t;
        auto a = t.experiment_programmable_op(0x5000, OpAdd, 13, 7, 8);
        check(a.ok && a.result==20, "R11 ADD still works");
    }

    std::cout << "\n========================================\n"
              << "Round 12: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
