#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
#include <sys/stat.h>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 17: Continuity under disruption ===\n";
    std::cout << "Differentiation → Unity → Continuity\n\n";

    const std::string wd = "/tmp/nan16_r17_work";
    mkdir(wd.c_str(), 0755);

    std::cout << "--- Interrupted commit ---\n";
    {
        Topology t;
        check(t.experiment_interrupted_commit(wd + "/interrupt.snap"),
              "uncommitted event not applied after restart");
    }

    std::cout << "\n--- Replay ---\n";
    {
        Topology t;
        check(t.experiment_replay(wd + "/replay.snap"),
              "replay reconstructs same collective hash");
    }

    std::cout << "\n--- Duplicate delivery ---\n";
    {
        Topology t;
        check(t.experiment_duplicate_delivery(),
              "second apply is no-op; fact count unchanged");
    }

    std::cout << "\n--- Delayed delivery / causal attribution ---\n";
    {
        Topology t;
        check(t.experiment_delayed_delivery(),
              "challenge retains parent event id");
    }

    std::cout << "\n--- Head reconstruction ---\n";
    {
        Topology t;
        check(t.experiment_head_reconstruction(),
              "identity + recoverable associations restored from snapshot");
    }

    std::cout << "\n--- Page migration ---\n";
    {
        Topology t;
        check(t.experiment_page_migration(),
              "tier1→tier2 copy preserves hash and head identity");
    }

    std::cout << "\n--- Collective recovery ---\n";
    {
        Topology t;
        check(t.experiment_collective_recovery(wd + "/recovery.snap"),
              "restart restores coherent contested state");
    }

    std::cout << "\n--- Disappearing head (star experiment) ---\n";
    {
        Topology t;
        auto d = t.experiment_disappearing_head(wd + "/disappear.snap");
        std::printf("  id=%d claims=%d prov=%d nodup=%d nopartial=%d hash=%d => all=%d\n",
            (int)d.identities_ok,(int)d.claims_survive,(int)d.provenance_ok,
            (int)d.no_dup,(int)d.no_partial,(int)d.hash_ok,(int)d.all_ok);
        check(d.identities_ok, "logical head identities survive restart");
        check(d.claims_survive, "both claims survive (contested)");
        check(d.provenance_ok, "challenge parent provenance survives");
        check(d.no_dup, "no duplicated committed events");
        check(d.no_partial, "uncommitted transition discarded");
        check(d.hash_ok, "canonical hash matches pre-crash committed state");
        check(d.all_ok, "DISAPPEARING HEAD EXPERIMENT PASSED");
    }

    std::cout << "\n--- Continuity suite ---\n";
    {
        Topology t;
        auto S = t.experiment_continuity_suite(wd);
        std::printf("  %d/%d\n", S.passed, S.tests);
        check(S.passed == S.tests, "continuity suite all green");
    }

    std::cout << "\n--- R16 regression ---\n";
    {
        Topology t;
        auto S = t.experiment_unity_suite();
        check(S.passed == S.tests, "R16 unity suite still green");
    }

    std::cout << "\n========================================\n"
              << "Round 17: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
