#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 11: Initial-State Programmability Challenge ===\n";
    std::cout << "ONE rule (RuleOpDispatch). Host never selects algorithm at runtime.\n\n";

    // Showcase table from the brief
    std::cout << "--- Showcase: 13 ? 7 under fixed rule map ---\n";
    {
        Topology t;
        auto add = t.experiment_programmable_op(0x1000, OpAdd, 13, 7, 8);
        auto xorr = t.experiment_programmable_op(0x1080, OpXor, 13, 7, 8);
        auto cmp = t.experiment_programmable_op(0x1100, OpCmp, 13, 7, 8);
        auto sub = t.experiment_programmable_op(0x1180, OpSub, 13, 7, 8);
        std::printf("  ADD  13+7  => %u (ok=%d) expect 20\n", add.result, (int)add.ok);
        std::printf("  XOR  13^7  => %u (ok=%d) expect 10\n", xorr.result, (int)xorr.ok);
        std::printf("  CMP  13?7  => %d (ok=%d) expect +1\n", cmp.cmp_code, (int)cmp.ok);
        std::printf("  SUB  13-7  => %u (ok=%d) expect 6\n", sub.result, (int)sub.ok);
        check(add.ok && add.result==20, "ADD 13+7=20");
        check(xorr.ok && xorr.result==10, "XOR 13^7=10");
        check(cmp.ok && cmp.cmp_code==1, "CMP 13>7");
        check(sub.ok && sub.result==6, "SUB 13-7=6");
        // Prove same rule_id on all cells after different ops
        check(t.at_address(0x1000).rule_id == RuleOpDispatch &&
              t.at_address(0x1080).rule_id == RuleOpDispatch &&
              t.at_address(0x1100).rule_id == RuleOpDispatch &&
              t.at_address(0x1180).rule_id == RuleOpDispatch,
              "all fields still RuleOpDispatch (never swapped)");
    }

    std::cout << "\n--- Full programmability battery ---\n";
    {
        Topology t;
        auto b = t.experiment_programmability_battery();
        std::printf("  cases %u/%u  ADD=%d SUB=%d XOR=%d AND=%d CMP=%d multi=%d\n",
            b.passed, b.cases, (int)b.add_ok,(int)b.sub_ok,(int)b.xor_ok,
            (int)b.and_ok,(int)b.cmp_ok,(int)b.multi_region_ok);
        check(b.passed == b.cases, "all battery cases pass");
        check(b.add_ok, "ADD family");
        check(b.sub_ok, "SUB family");
        check(b.xor_ok, "XOR family");
        check(b.and_ok, "AND family");
        check(b.cmp_ok, "CMP family");
        check(b.multi_region_ok, "four simultaneous regions, four ops, one rule");
        check(b.schedule_ok, "schedule/add path ok");
        check(b.dual_rail_ok, "add under dual-capable field");
    }

    std::cout << "\n--- Stress: many random-ish inputs, fixed rule ---\n";
    {
        Topology t;
        int ok = 0, n = 0;
        std::uint32_t inputs[][2] = {
            {0,0},{1,0},{0,1},{1,1},{15,1},{128,127},{200,55},{0x55,0xAA},
            {0x0F,0xF0},{50,50},{99,1},{255,255}
        };
        for (auto& ab : inputs) {
            for (OpCode op : {OpAdd, OpSub, OpXor, OpAnd}) {
                ++n;
                auto r = t.experiment_programmable_op(0x4000, op, ab[0], ab[1], 8);
                if (r.ok) ++ok;
            }
            ++n;
            auto c = t.experiment_programmable_op(0x4080, OpCmp, ab[0], ab[1], 8);
            if (c.ok) ++ok;
        }
        std::printf("  stress %d/%d\n", ok, n);
        check(ok == n, "stress battery all ops × 12 input pairs");
    }

    std::cout << "\n--- Regression: R10 challenge still green ---\n";
    {
        Topology t;
        auto c = t.experiment_mirror_machine_challenge();
        check(c.all_ok, "R10 mirror machine challenge subset");
    }

    std::cout << "\n========================================\n"
              << "Round 11: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
