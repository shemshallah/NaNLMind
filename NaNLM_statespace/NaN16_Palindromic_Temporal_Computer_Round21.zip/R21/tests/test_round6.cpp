#include "nan16_ptc.hpp"
#include <cassert>
#include <cstdio>
#include <iostream>
#include <vector>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 6: signal-carried adder + event-driven ===\n";

    // 1. Signal-carried addition family
    {
        Topology t;
        struct C { std::uint32_t a,b; int bits; };
        C cases[] = {
            {0,0,4},{1,1,4},{7,1,4},{22,11,8},{0xFF,1,8},{0xAA,0x55,8},
            {0x1234,0x00ED,16},{0xFFFF,1,16},
        };
        int ok=0, total=0;
        for (auto& c : cases) {
            ++total;
            auto r = t.run_signal_adder(0x8000, c.a, c.b, c.bits, c.bits * 4 + 8);
            std::uint32_t mask = (c.bits>=32)?0xFFFFFFFFu:((1u<<c.bits)-1u);
            std::uint32_t expect = (c.a + c.b) & mask;
            bool p = r.ok && ((r.result & mask) == expect);
            if (p) ++ok;
            std::printf("  %u+%u (%d-bit) => %u expect %u steps=%d hops=%d %s\n",
                c.a,c.b,c.bits,r.result&mask,expect,r.steps,r.hops,p?"OK":"BAD");
            // Ripple should take about `bits` steps (one hop per bit)
            if (p && c.a+c.b != 0)
                check(r.steps >= 1 && r.steps <= c.bits + 2, "step count near bit-width");
        }
        check(ok==total, "all signal-carried adder cases");
        std::cout << "  " << ok << "/" << total << " signal-add cases\n";
    }

    // 2. Event-driven sparse update vs full step on a small seed
    {
        Topology t;
        t.set_all_rule(RuleSignalPropagate);
        t.at_address(0x0100).signal = 3;
        std::vector<std::uint16_t> dirty = {0x0100};
        int steps = 0;
        std::uint32_t total_fired = 0;
        while (!dirty.empty() && steps < 20) {
            total_fired += t.step_event_driven(dirty);
            ++steps;
        }
        check(t.at_address(0x0100).signal == 0, "event-driven signal eventually quiet");
        check(steps > 0 && total_fired > 0, "event-driven performed work");
        std::printf("  event-driven: steps=%d total_fired=%u final_dirty=%zu\n",
            steps, total_fired, dirty.size());
    }

    // 3. Programmability smoke: same rule map, different initial state → different results
    {
        Topology t1, t2;
        auto r1 = t1.run_signal_adder(0x9000, 3, 4, 8);
        auto r2 = t2.run_signal_adder(0x9000, 10, 5, 8);
        check(r1.ok && r2.ok && r1.result != r2.result, "initial state alone selects different sums");
        check(r1.result == 7 && r2.result == 15, "3+4=7 and 10+5=15");
    }

    // 4. Regression dual geometric adder
    {
        Topology t;
        auto dr = t.run_dual_adders(0x4000, 22, 11, 8, 0x4100, 100, 23, 8, 0);
        check(dr.a_ok && dr.b_ok, "dual geometric adder regression");
    }

    std::cout << "\nRound 6: " << pass << " passed, " << fail << " failed\n";
    return fail ? 1 : 0;
}
