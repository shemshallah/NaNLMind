#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
#include <cmath>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 15: Collective State Space + 256 Cognitive Heads ===\n\n";

    // --- Init on fixed points ---
    std::cout << "--- Head initialization ---\n";
    {
        Topology t;
        t.heads_init();
        check(t.head_count() == 256, "256 heads");
        int fp_ok = 0;
        for (int i = 0; i < 256; ++i) {
            std::uint16_t a = t.head(i).fixed_addr;
            std::uint16_t rev = 0;
            for (int b = 0; b < 16; ++b) if (a & (1u << b)) rev |= (1u << (15 - b));
            if (rev == a) ++fp_ok;
        }
        std::printf("  fixed-point anchors: %d/256\n", fp_ok);
        check(fp_ok == 256, "every head anchored on bit-reversal fixed point");
    }

    // --- Specialization without predefined roles ---
    std::cout << "\n--- Specialization (emergent roles) ---\n";
    {
        Topology t;
        t.heads_init();
        for (int round = 0; round < 50; ++round)
            for (int cls = 0; cls < 8; ++cls)
                t.heads_present_task(cls, static_cast<std::uint16_t>(round * 16 + cls * 3));
        auto spec = t.heads_measure_specialization();
        std::printf("  mean_entropy=%.4f (max=%.4f) emergent=%d\n",
            spec.mean_entropy, std::log(8.0), (int)spec.emergent);
        std::printf("  dominant heads per class:");
        for (int k = 0; k < 8; ++k) std::printf(" %d", spec.dominant_heads[k]);
        std::printf("\n");
        check(spec.emergent, "different heads dominate different task classes");
        check(spec.mean_entropy < std::log(8.0) - 0.01, "entropy below uniform (specialization)");
    }

    // --- Head-to-head communication ---
    std::cout << "\n--- Head-to-head communication ---\n";
    {
        Topology t;
        t.heads_init();
        float a0 = t.head(10).activation;
        check(t.heads_send(3, 10, 4, 99), "ACTIVATE message delivered");
        check(t.heads_send(10, 11, 0, 7), "SIGNAL delivered");
        check(t.heads_send(11, 10, 3, 1), "CHALLENGE delivered");
        int n = t.heads_process_inbox();
        std::printf("  processed=%d act10=%.3f conf10=%.3f\n",
            n, t.head(10).activation, t.head(10).confidence);
        check(n >= 3, "inbox processed");
        check(t.head(10).activation > a0, "activation changed after messages");
    }

    // --- Head-level memory ---
    std::cout << "\n--- Head-level associative memory ---\n";
    {
        Topology t;
        t.heads_init();
        t.head_remember(42, 100, 200);
        t.head_remember(42, 101, 201);
        std::uint16_t v = 0;
        check(t.head_recall(42, 100, v) && v == 200, "recall key 100");
        check(t.head_recall(42, 101, v) && v == 201, "recall key 101");
        check(!t.head_recall(42, 999, v), "miss unknown key");
        check(!t.head_recall(43, 100, v), "other head does not share memory");
    }

    // --- Query via messaging ---
    std::cout << "\n--- QUERY/PROPOSE dialogue ---\n";
    {
        Topology t;
        t.heads_init();
        t.head_remember(7, 55, 77);
        t.heads_send(1, 7, 1, 55); // QUERY key 55
        t.heads_process_inbox();
        // head 7 may PROPOSE back to 1
        t.heads_process_inbox();
        check(t.head(7).assoc_n >= 1, "head 7 retains association after query");
    }

    // --- Full suite ---
    std::cout << "\n--- Heads suite ---\n";
    {
        Topology t;
        auto S = t.experiment_heads_suite();
        std::printf("  %d/%d init=%d spec=%d comm=%d mem=%d dual=%d css=%d\n",
            S.passed, S.tests, (int)S.init_ok, (int)S.specialization_ok,
            (int)S.communication_ok, (int)S.memory_ok,
            (int)S.dual_with_heads_ok, (int)S.css_doc_present);
        check(S.passed == S.tests, "all suite tests pass");
    }

    // --- R14 regression ---
    std::cout << "\n--- R14 cognitive regression ---\n";
    {
        Topology t;
        auto S = t.experiment_cognitive_suite();
        check(S.passed == S.tests, "R14 cognitive suite still green");
    }

    std::cout << "\n========================================\n"
              << "Round 15: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
