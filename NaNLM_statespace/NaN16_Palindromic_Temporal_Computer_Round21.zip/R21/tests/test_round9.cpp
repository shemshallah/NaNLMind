#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 9: host-blind local-rule logic machine ===\n\n";

    // Local XOR / AND gates — host does not compute outputs
    std::cout << "--- Local gates ---\n";
    {
        Topology t;
        int ok = 0;
        for (int x = 0; x < 2; ++x)
            for (int y = 0; y < 2; ++y) {
                auto g = t.experiment_local_gates(0x0100, (std::uint8_t)x, (std::uint8_t)y);
                std::printf("  %d XOR %d = %u (ok=%d)  %d AND %d = %u (ok=%d)\n",
                    x,y,g.xor_out,(int)g.xor_ok, x,y,g.and_out,(int)g.and_ok);
                if (g.xor_ok && g.and_ok) ++ok;
            }
        check(ok == 4, "all XOR/AND local gate cases");
    }

    // Pure local adder — host seeds + steps only
    std::cout << "\n--- Pure local-rule adder (host-blind) ---\n";
    {
        Topology t;
        struct C { std::uint32_t a,b; int bits; };
        C cases[] = {
            {0,0,4},{1,1,4},{7,1,4},{22,11,8},{0xAA,0x55,8},
            {0x1234,0x00ED,16},{0xFFFF,1,16},
        };
        int ok=0;
        for (auto& c : cases) {
            auto r = t.experiment_pure_local_adder(0x2000, c.a, c.b, c.bits);
            std::uint32_t mask = (c.bits>=32)?0xFFFFFFFFu:((1u<<c.bits)-1u);
            std::printf("  %u+%u (%d-bit) => %u expect %u steps=%d ok=%d\n",
                c.a,c.b,c.bits,r.result&mask,(c.a+c.b)&mask,r.steps,(int)r.ok);
            if (r.ok) ++ok;
        }
        check(ok == 7, "all pure local adder cases");
    }

    // Two independent pure adders
    std::cout << "\n--- Two independent pure local adders ---\n";
    {
        Topology t;
        auto r = t.experiment_two_pure_adders(
            0x3000, 22, 11, 8,
            0x3100, 100, 27, 8);
        std::printf("  22+11=%u ok=%d  100+27=%u ok=%d\n",
            r.r0,(int)r.ok0,r.r1,(int)r.ok1);
        check(r.ok0 && r.ok1, "two pure local adders both correct");
    }

    // Forward then recover via dual complementary still works alongside
    std::cout << "\n--- Dual complementary still available ---\n";
    {
        Topology t;
        auto c = t.experiment_complementary_xor(0x4000, 0x11111111u);
        check(c.recovered, "complementary recovery still works");
    }

    std::cout << "\nRound 9: " << pass << " passed, " << fail << " failed\n";
    return fail ? 1 : 0;
}
