#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 21: Formal logic + puzzles ===\n\n";

    std::cout << "── Syllogism (Barbara) ──\n";
    {
        Topology t;
        bool ok = t.experiment_syllogism_barbara();
        std::cout << "  Socrates is man, men are mortal ⊢ Socrates mortal\n";
        check(ok, "Barbara syllogism");
    }

    std::cout << "\n── Modus ponens ──\n";
    {
        Topology t;
        check(t.experiment_modus_ponens(), "P→Q, P ⊢ Q");
    }

    std::cout << "\n── Modus tollens ──\n";
    {
        Topology t;
        check(t.experiment_modus_tollens(), "P→Q, ¬Q ⊢ ¬P");
    }

    std::cout << "\n── Hypothetical syllogism ──\n";
    {
        Topology t;
        check(t.experiment_hypothetical_syllogism(), "P→Q, Q→R, P ⊢ R");
    }

    std::cout << "\n── Contradiction contained ──\n";
    {
        Topology t;
        check(t.experiment_contradiction_contained(),
              "P∧¬P detected; does not explode to arbitrary Q");
    }

    std::cout << "\n── Proof chain (12 implications) ──\n";
    {
        Topology t;
        auto C = t.experiment_proof_chain(12);
        std::printf("  derived=%d steps=%d\n", (int)C.derived, C.chain_steps);
        check(C.derived && C.chain_steps >= 12, "P0→…→P12 forward chain");
    }

    std::cout << "\n── Disjunctive syllogism ──\n";
    {
        Topology t;
        check(t.experiment_disjunctive_syllogism(), "¬P, (¬P→Q) ⊢ Q");
    }

    std::cout << "\n── Puzzle: three boxes (all labels wrong) ──\n";
    {
        Topology t;
        auto B = t.experiment_puzzle_three_boxes();
        std::printf("  gold_box=%d solved=%d\n", B.gold_box, (int)B.solved);
        check(B.solved && B.gold_box == 2, "gold is in box 2");
    }

    std::cout << "\n── Puzzle: social asymmetry ──\n";
    {
        Topology t;
        auto S = t.experiment_puzzle_social_graph();
        check(S.all_ok, "knows-edge asymmetric (no false symmetry)");
    }

    std::cout << "\n── Formal suite ──\n";
    {
        Topology t;
        auto S = t.experiment_formal_suite();
        std::printf("  %d/%d  barbara=%d mp=%d mt=%d hs=%d contra=%d boxes=%d chain=%d ds=%d\n",
            S.passed, S.tests, (int)S.barbara,(int)S.mp,(int)S.mt,(int)S.hs,
            (int)S.contra,(int)S.boxes,(int)S.chain,(int)S.ds);
        check(S.passed == S.tests, "FORMAL SUITE GREEN");
    }

    std::cout << "\n── R20 extreme regression ──\n";
    {
        Topology t;
        auto S = t.experiment_extreme_cognition();
        check(S.passed == S.tests, "R20 extreme still green");
    }

    std::cout << "\n========================================\n"
              << "Round 21: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
