#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
#include <cmath>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 16: Unity under differentiation ===\n";
    std::cout << "Head identity ≠ physical location · Head plurality ≠ state plurality\n\n";

    // 1 Shared-fact propagation
    std::cout << "--- Shared-fact propagation ---\n";
    {
        Topology t;
        check(t.experiment_shared_fact_propagation(),
              "fact from head 3 available to collective query");
    }

    // 2 Conflicting conclusions
    std::cout << "\n--- Conflicting conclusions ---\n";
    {
        Topology t;
        auto c = t.experiment_conflicting_conclusions();
        std::printf("  preserved=%d contested=%d third_sees=%d intact=%d\n",
            (int)c.both_preserved,(int)c.contested,(int)c.third_sees_both,(int)c.shared_state_intact);
        check(c.both_preserved, "both opposing facts retained");
        check(c.contested, "conflict marked contested");
        check(c.third_sees_both, "third head sees disagreement, not false yes");
        check(c.shared_state_intact, "shared state not overwritten");
    }

    // 3 Attribution
    std::cout << "\n--- Cross-head attribution ---\n";
    {
        Topology t;
        t.heads_init();
        t.collective_clear();
        auto e = t.collective_propose(17, Topology::C_BIRD, Topology::R_HAS, Topology::C_WINGS);
        auto q = t.collective_query(Topology::C_BIRD, Topology::R_HAS, Topology::C_WINGS);
        check(q.origin_head == 17 && q.event_id == e, "origin head and event id preserved");
    }

    // 4 Specialization stability
    std::cout << "\n--- Specialization stability ---\n";
    {
        Topology t;
        auto s = t.experiment_specialization_stability();
        std::printf("  entropy %.3f → %.3f same_dominants=%d stable=%d\n",
            s.entropy_before, s.entropy_after, s.same_dominants, (int)s.stable);
        check(s.stable, "specialization stable across distribution shift");
    }

    // 5 Transfer
    std::cout << "\n--- Specialization transfer ---\n";
    {
        Topology t;
        auto tr = t.experiment_specialization_transfer();
        std::printf("  old %u→%u new=%u retained=%d acquired=%d\n",
            tr.old_score_before, tr.old_score_after, tr.new_score_after,
            (int)tr.retained, (int)tr.acquired);
        check(tr.retained, "prior specialty score not erased");
        check(tr.acquired, "new competency acquired");
    }

    // 6 Head failure
    std::cout << "\n--- Head failure ---\n";
    {
        Topology t;
        auto f = t.experiment_head_failure(99);
        check(f.head_reset, "victim local state cleared");
        check(f.identity_unchanged, "logical identity (id + fixed_addr) unchanged");
        check(f.others_intact, "other heads unaffected");
        check(f.collective_intact, "collective facts survive head reset");
    }

    // 7 Physical relocation
    std::cout << "\n--- Physical relocation ---\n";
    {
        Topology t;
        check(t.experiment_physical_relocation(),
              "logical identity independent of physical page cell");
    }

    // 8 Schedule consistency
    std::cout << "\n--- Schedule consistency ---\n";
    {
        Topology t;
        check(t.experiment_schedule_consistency(),
              "forward and reverse propose order → same content hash");
    }

    // Full suite
    std::cout << "\n--- Unity suite ---\n";
    {
        Topology t;
        auto S = t.experiment_unity_suite();
        std::printf("  %d/%d shared=%d conflict=%d stab=%d xfer=%d fail=%d reloc=%d sched=%d\n",
            S.passed, S.tests, (int)S.shared,(int)S.conflict,(int)S.stability,
            (int)S.transfer,(int)S.failure,(int)S.relocation,(int)S.schedule);
        check(S.passed == S.tests, "unity suite all green");
    }

    // R15 regression
    std::cout << "\n--- R15 regression ---\n";
    {
        Topology t;
        auto S = t.experiment_heads_suite();
        check(S.passed == S.tests, "R15 heads suite still green");
    }

    std::cout << "\n========================================\n"
              << "Round 16: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
