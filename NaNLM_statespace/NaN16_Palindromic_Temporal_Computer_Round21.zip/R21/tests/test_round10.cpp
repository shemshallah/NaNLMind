#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}
static void section(const char* s) { std::cout << "\n=== " << s << " ===\n"; }

int main() {
    std::cout << "NaN16 PTC Round 10 — ABSOLUTE CHECKPOINT SUITE\n";

    // ----- 1. Host independence -----
    section("1. Host-independence (local gates + pure adder)");
    {
        Topology t;
        int gok = 0;
        for (int x=0;x<2;++x) for (int y=0;y<2;++y) {
            auto g = t.experiment_local_gates(0x0100, x, y);
            if (g.xor_ok && g.and_ok) ++gok;
        }
        check(gok==4, "local XOR/AND all inputs (host-blind)");
        auto a = t.experiment_pure_local_adder(0x0200, 22, 11, 8);
        check(a.ok && a.result==33, "pure local adder 22+11=33");
        auto a2 = t.experiment_pure_local_adder(0x0280, 0x1234, 0x00ED, 16);
        check(a2.ok, "pure local 16-bit adder");
    }

    // ----- 2. Mirror independence & cooperation -----
    section("2. Mirror independence & cooperation");
    {
        Topology t;
        auto ind = t.experiment_mirror_independence(0x0300, true);
        check(ind.isolation_ok, "S+ touch isolates S-");
        auto ind2 = t.experiment_mirror_independence(0x0300, false);
        check(ind2.isolation_ok, "S- touch isolates S+");
        auto coop = t.experiment_dual_cooperation(0x0400, 22, 11, 8);
        std::printf("  dual coop: arith=%d minus_intact=%d recover=%d\n",
            (int)coop.plus_arith_ok,(int)coop.minus_intact,(int)coop.recover_ok);
        check(coop.plus_arith_ok && coop.minus_intact && coop.recover_ok,
              "dual cooperation: arith + intact S- + recover");
        auto bulk = t.experiment_dual_bulk(0x0500, 256, 20);
        check(bulk.isolation_failures==0 && bulk.complementary_ok==256, "bulk dual 256 cells clean");
    }

    // ----- 3. Reversible gates -----
    section("3. Reversible gates (NOT/CNOT/Toffoli/Fredkin)");
    {
        Topology t;
        auto r = t.experiment_reversible_gates(256);
        std::printf("  NOT=%d CNOT=%d Toffoli=%d Fredkin=%d (passed %u/4)\n",
            (int)r.not_ok,(int)r.cnot_ok,(int)r.toffoli_ok,(int)r.fredkin_ok, r.passed);
        check(r.not_ok, "NOT is involution on 256 trials");
        check(r.cnot_ok, "CNOT is involution on 256 trials");
        check(r.toffoli_ok, "Toffoli is involution on 256 trials");
        check(r.fredkin_ok, "Fredkin is involution on 256 trials");
    }

    // ----- 4. Fixed-rule programmability -----
    section("4. Fixed rule map, programs = initial state");
    {
        Topology t;
        auto p = t.experiment_fixed_rule_programs(0x0600, 0x0680);
        std::printf("  prog0(3+5)=%u prog1(20+22)=%u\n", p.r_prog0, p.r_prog1);
        check(p.both_ok && p.distinct, "same engine, different initial state → different correct results");
        check(p.r_prog0==8 && p.r_prog1==42, "3+5=8 and 20+22=42");
    }

    // ----- 5. Schedule independence -----
    section("5. Asynchronous / schedule matrix");
    {
        Topology t;
        auto s = t.experiment_schedule_matrix(0x0700, 22, 11, 8);
        std::printf("  sync=%u rev=%u scramble=%u expect_ok=%d match_sync_rev=%d\n",
            s.result_sync, s.result_rev, s.result_scramble, (int)s.expect_ok, (int)s.all_match);
        check(s.expect_ok, "sync schedule yields correct sum");
        check(s.all_match, "reverse activation order matches sync (causal closure)");
        auto oi = t.experiment_order_independence(0x1000, 0x5000, 16, 6);
        check(oi.independent, "disjoint regions order-independent under event-driven");
    }

    // ----- 6. Fault detect + recover -----
    section("6. Self-check / fault recovery");
    {
        Topology t;
        auto f = t.experiment_fault_recovery(0x0800, 22, 11, 8);
        std::printf("  faults=%u recoveries=%u detected=%d recovered=%d\n",
            f.faults_tested, f.recoveries, (int)f.detected, (int)f.recovered);
        check(f.detected, "faults detected via shadow/verify");
        check(f.recovered && f.recoveries==f.faults_tested, "all injected faults recovered");
    }

    // ----- 7. Scale facts -----
    section("7. Topology scale (exact)");
    {
        Topology t;
        check(t.fixed_points().size()==256, "256 fixed points");
        check(t.cell_count()==65536, "address table sized to 65536");
    }

    // ----- 8. Regressions from prior rounds -----
    section("8. Regression battery");
    {
        Topology t;
        check(t.run_signal_adder(0x9000,22,11,8).ok, "R6 signal adder");
        check(t.experiment_pure_local_adder(0x9100,100,27,8).ok, "R9 pure adder");
        auto dual = t.run_dual_adders(0x9200,22,11,8,0x9280,100,23,8,0);
        check(dual.a_ok && dual.b_ok, "R4 dual geometric adders");
        // Rule 110
        std::vector<std::uint8_t> bits(32,0); bits[30]=1;
        t.seed_linear_rule110(0x9300, 32, bits);
        for (int i=0;i<10;++i) t.step_rule110_line(0x9300, 32);
        check(true, "Rule 110 still runs");
    }

    // ----- Mirror Machine Challenge -----
    section("9. Mirror Machine Challenge (subset)");
    {
        Topology t;
        auto c = t.experiment_mirror_machine_challenge();
        std::printf("  arith=%d gates=%d reverse=%d schedule=%d fault=%d => all=%d\n",
            (int)c.arith_ok,(int)c.gates_ok,(int)c.reverse_ok,
            (int)c.schedule_ok,(int)c.fault_ok,(int)c.all_ok);
        check(c.arith_ok, "challenge: arithmetic");
        check(c.gates_ok, "challenge: gates");
        check(c.reverse_ok, "challenge: reverse recovery");
        check(c.schedule_ok, "challenge: schedule equivalence");
        check(c.fault_ok, "challenge: fault recovery");
        check(c.all_ok, "MIRROR MACHINE CHALLENGE (subset) PASSED");
    }

    std::cout << "\n========================================\n"
              << "Round 10 TOTAL: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
