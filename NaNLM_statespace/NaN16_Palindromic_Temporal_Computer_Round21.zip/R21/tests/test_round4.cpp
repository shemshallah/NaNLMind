#include "nan16_ptc.hpp"
#include <cassert>
#include <cstdio>
#include <iostream>
#include <string>
#include <vector>

using namespace nan16;

static int g_pass = 0, g_fail = 0;
static void expect(bool cond, const char* msg) {
    if (cond) { ++g_pass; std::cout << "  PASS: " << msg << "\n"; }
    else      { ++g_fail; std::cout << "  FAIL: " << msg << "\n"; }
}
static void section(const char* t) { std::cout << "\n=== " << t << " ===\n"; }

int main() {
    // ------------------------------------------------------------------
    section("1. Topology + fixed points");
    {
        Topology t;
        auto fps = t.fixed_points();
        expect(fps.size() == 256, "256 bit-palindromic fixed points");
        expect(t.at_address(0x8001).is_fixed_point(), "0x8001 is fixed");
        expect(!t.at_address(0x1234).is_fixed_point(), "0x1234 is not fixed");
        std::cout << "  fixed-point count = " << fps.size() << "\n";
    }

    // ------------------------------------------------------------------
    section("2. Rule 90 Sierpinski (no PC)");
    {
        Topology t;
        const std::uint16_t start = 0x1000, len = 32;
        t.seed_linear_rule90(start, len, 0);
        t.at_address(start + 16).state = 1;
        std::string s0 = t.snapshot_line(start, len);
        for (int i = 0; i < 8; ++i) t.step_rule90_line(start, len);
        std::string s8 = t.snapshot_line(start, len);
        int ones = 0; for (char c : s8) if (c == '1') ++ones;
        expect(ones > 1 && s8 != s0, "Rule 90 produces Sierpinski-like pattern");
        std::cout << "  t0: " << s0 << "\n  t8: " << s8 << "\n";
    }

    // ------------------------------------------------------------------
    section("3. Rule 110 embedding (universality path)");
    {
        Topology t;
        const std::uint16_t start = 0x2000, len = 64;
        // Classic Rule 110 seed: single 1 near the right
        std::vector<std::uint8_t> bits(len, 0);
        bits[len - 2] = 1;
        t.seed_linear_rule110(start, len, bits);

        // Reference Rule 110 evolution (simple host implementation)
        auto ref_step = [](std::vector<std::uint8_t>& row) {
            std::vector<std::uint8_t> n(row.size());
            static const std::uint8_t tab[8] = {0,1,1,1,0,1,1,0};
            for (size_t i = 0; i < row.size(); ++i) {
                std::uint8_t L = row[(i + row.size() - 1) % row.size()];
                std::uint8_t S = row[i];
                std::uint8_t R = row[(i + 1) % row.size()];
                n[i] = tab[(L << 2) | (S << 1) | R];
            }
            row.swap(n);
        };

        std::vector<std::uint8_t> ref = bits;
        bool match = true;
        for (int step = 0; step < 30; ++step) {
            t.step_rule110_line(start, len);
            ref_step(ref);
            for (std::uint16_t i = 0; i < len; ++i) {
                if ((t.at_address(start + i).state & 1u) != ref[i]) { match = false; break; }
            }
            if (!match) break;
        }
        expect(match, "Rule 110 matches reference for 30 steps");
        std::cout << "  final snapshot: " << t.snapshot_line(start, 32) << "...\n";
    }

    // ------------------------------------------------------------------
    section("4. Arithmetic scaling — adder family");
    {
        Topology t;
        struct Case { std::uint32_t a, b; int bits; };
        Case cases[] = {
            {0, 0, 4}, {1, 1, 4}, {7, 1, 4},
            {22, 11, 8}, {0xFF, 0x01, 8}, {0xAA, 0x55, 8},
            {0x1234, 0x00ED, 16}, {0xFFFF, 0x0001, 16},
        };
        int ok = 0, total = 0;
        for (auto& c : cases) {
            ++total;
            // Mask to width
            std::uint32_t mask = (c.bits == 32) ? 0xFFFFFFFFu : ((1u << c.bits) - 1u);
            std::uint32_t expect_sum = (c.a + c.b) & mask;
            std::uint32_t got = t.run_adder(0x3000, c.a, c.b, c.bits, c.bits + 4);
            got &= mask;
            bool pass = (got == expect_sum);
            if (pass) ++ok;
            std::printf("  %u + %u (%d-bit) => got %u expect %u %s\n",
                        c.a, c.b, c.bits, got, expect_sum, pass ? "OK" : "BAD");
        }
        expect(ok == total, "all adder cases match");
        std::cout << "  " << ok << "/" << total << " adder cases passed\n";
    }

    // ------------------------------------------------------------------
    section("5. Subtraction (borrow wave)");
    {
        Topology t;
        struct Case { std::uint32_t a, b; int bits; };
        Case cases[] = {
            {5, 3, 4}, {8, 1, 4}, {22, 11, 8}, {0x100, 0x001, 16},
        };
        int ok = 0, total = 0;
        for (auto& c : cases) {
            ++total;
            std::uint32_t mask = (1u << c.bits) - 1u;
            std::uint32_t expect_diff = (c.a - c.b) & mask;
            std::uint32_t got = t.run_subtractor(0x3100, c.a, c.b, c.bits, c.bits + 4);
            got &= mask;
            bool pass = (got == expect_diff);
            if (pass) ++ok;
            std::printf("  %u - %u (%d-bit) => got %u expect %u %s\n",
                        c.a, c.b, c.bits, got, expect_diff, pass ? "OK" : "BAD");
        }
        expect(ok == total, "all subtractor cases match");
    }

    // ------------------------------------------------------------------
    section("6. Comparison wave (MSB-first)");
    {
        Topology t;
        struct Case { std::uint32_t a, b; int bits; int expect; };
        Case cases[] = {
            {5, 3, 4, 1}, {3, 5, 4, -1}, {7, 7, 4, 0},
            {100, 50, 8, 1}, {50, 100, 8, -1}, {0xABCD, 0xABCD, 16, 0},
        };
        int ok = 0, total = 0;
        for (auto& c : cases) {
            ++total;
            int got = t.run_compare(0x3200, c.a, c.b, c.bits, c.bits + 4);
            bool pass = (got == c.expect);
            if (pass) ++ok;
            std::printf("  cmp(%u,%u) => %d expect %d %s\n",
                        c.a, c.b, got, c.expect, pass ? "OK" : "BAD");
        }
        expect(ok == total, "all compare cases match");
    }

    // ------------------------------------------------------------------
    section("7. Dual simultaneous arithmetic fields (mirror orientation)");
    {
        Topology t;
        // Field A: 22+11 at 0x4000 (forward)
        // Field B: 100+23 at 0x4100 (reverse orientation mark)
        auto dr = t.run_dual_adders(
            0x4000, 22, 11, 8,
            0x4100, 100, 23, 8,
            16);
        std::printf("  field A: 22+11 => %u (ok=%d)\n", dr.result_a, (int)dr.a_ok);
        std::printf("  field B: 100+23 => %u (ok=%d)\n", dr.result_b, (int)dr.b_ok);
        std::printf("  steps=%d\n", dr.steps);
        expect(dr.a_ok, "dual field A correct");
        expect(dr.b_ok, "dual field B correct");
        expect(dr.a_ok && dr.b_ok, "two independent additions in one topology");
    }

    // ------------------------------------------------------------------
    section("8. Reversibility audit");
    {
        std::cout << "  Rule classification:\n";
        for (std::uint8_t id = 0; id <= 10; ++id) {
            auto* m = Topology::rule_meta(id);
            if (!m) continue;
            const char* rc = "?";
            switch (m->rev) {
            case RevClass::FullyReversible: rc = "FULL"; break;
            case RevClass::ConditionallyReversible: rc = "COND"; break;
            case RevClass::Irreversible: rc = "IRREV"; break;
            case RevClass::NeedsHistory: rc = "HIST"; break;
            }
            std::printf("    [%2u] %-16s  %s  — %s\n", id, m->name, rc, m->note);
        }
        // Local involution probe for ReversibleXOR
        Topology t;
        t.set_all_rule(RuleReversibleXOR);
        Cell& c = t.at_address(0x5000);
        c.state = 0xA5;
        std::uint32_t orig = c.state;
        std::uint32_t frozen = 0x3;
        c.state ^= frozen;
        c.state ^= frozen;
        expect(c.state == orig, "ReversibleXOR is local involution under frozen mask");
    }

    // ------------------------------------------------------------------
    section("9. Fixed-point observation network");
    {
        Topology t;
        auto fps = t.fixed_points();
        // Plant activity near a few fixed points
        for (int i = 0; i < 8 && i < (int)fps.size(); ++i) {
            t.at_address(fps[i]).state = 1;
            t.at_address(fps[i]).signal = 3;
        }
        auto near = t.count_active_near_fixed(1);
        expect(near >= 8, "fixed-point neighborhood shows activity");
        std::cout << "  active near fixed points (r=1): " << near << "\n";

        // Symmetry preservation probe: seed a pair symmetrically, step Rule90 line
        // on a window that includes a fixed point, check mirror consistency is still definable
        expect(fps.size() == 256, "fixed-point set intact after activity");
    }

    // ------------------------------------------------------------------
    section("10. Temporal hash / cycle detection probe");
    {
        Topology t;
        t.seed_linear_rule90(0x6000, 16, 0x00FF);
        std::vector<std::uint64_t> hashes;
        bool cycle = false;
        int period = -1;
        for (int step = 0; step < 64; ++step) {
            auto h = t.state_hash();
            for (size_t i = 0; i < hashes.size(); ++i) {
                if (hashes[i] == h) { cycle = true; period = (int)(hashes.size() - i); break; }
            }
            if (cycle) break;
            hashes.push_back(h);
            t.step_rule90_line(0x6000, 16);
        }
        std::cout << "  cycle_detected=" << cycle << " period=" << period
                  << " hashes_collected=" << hashes.size() << "\n";
        // A small 16-cell Rule 90 ring is finite → must eventually cycle
        expect(cycle || hashes.size() == 64, "finite topology eventually cycles or hit step limit");
    }

    // ------------------------------------------------------------------
    section("11. Signal chemistry sketch (annihilation)");
    {
        Topology t;
        t.set_all_rule(RuleSignalPropagate);
        // Two signals approaching via Hamming neighborhood from different seeds
        t.at_address(0x0100).signal = 4;
        t.at_address(0x0101).signal = 4; // adjacent
        for (int i = 0; i < 6; ++i) t.step_synchronous();
        // After decay, signals should be gone
        expect(t.at_address(0x0100).signal == 0 && t.at_address(0x0101).signal == 0,
               "signals decay to zero (annihilation/expiry)");
    }

    // ------------------------------------------------------------------
    std::cout << "\n========================================\n"
              << "Round 4 results: " << g_pass << " passed, " << g_fail << " failed\n"
              << "========================================\n";
    return g_fail ? 1 : 0;
}
