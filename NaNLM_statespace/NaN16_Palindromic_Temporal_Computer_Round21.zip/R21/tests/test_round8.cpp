#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 8: local dual rules, dual-rail add, order independence ===\n\n";

    // Exp: local dual couple / cross via registered rules + synchronous step
    std::cout << "--- Local dual couple / cross ---\n";
    {
        Topology t;
        auto r = t.experiment_local_dual_couple(0x1000, 32, 5, false);
        std::printf("  couple: hash %llx → %llx changed=%d\n",
            (unsigned long long)r.hash_before, (unsigned long long)r.hash_after,
            (int)r.cross_changed_both);
        check(r.hash_before != r.hash_after, "dual couple evolves state");

        Topology t2;
        auto x = t2.experiment_local_dual_couple(0x1000, 32, 5, true);
        std::printf("  cross:  hash %llx → %llx both_sides=%d\n",
            (unsigned long long)x.hash_before, (unsigned long long)x.hash_after,
            (int)x.cross_changed_both);
        check(x.cross_changed_both, "dual cross changes both S+ and S-");
    }

    // Pair-to-pair NAND chain
    std::cout << "\n--- NAND chain (pair-to-pair logic) ---\n";
    {
        Topology t;
        auto h1 = t.experiment_nand_chain(0x2000, 16, 1);
        Topology t2;
        auto h4 = t2.experiment_nand_chain(0x2000, 16, 4);
        std::printf("  nand hash t=1: %llx  t=4: %llx\n",
            (unsigned long long)h1, (unsigned long long)h4);
        check(true, "nand chain runs to completion");
        // deterministic: same seed same steps → same hash
        Topology t3;
        auto h1b = t3.experiment_nand_chain(0x2000, 16, 1);
        check(h1 == h1b, "nand chain is deterministic");
    }

    // Dual-rail signal add
    std::cout << "\n--- Dual-rail signal add ---\n";
    {
        Topology t;
        struct C { std::uint32_t a,b; int bits; };
        C cases[] = {{22,11,8},{7,1,4},{0xFF,1,8},{100,27,8}};
        int ok=0;
        for (auto& c : cases) {
            auto r = t.experiment_dual_rail_add(0x3000, c.a, c.b, c.bits);
            std::printf("  %u+%u => %u arith=%d shadow=%d steps=%d\n",
                c.a,c.b,r.result,(int)r.arithmetic_ok,(int)r.shadow_intact,r.steps);
            if (r.arithmetic_ok && r.shadow_intact) ++ok;
        }
        check(ok == 4, "dual-rail add: arithmetic + shadow validation");
    }

    // Order independence of disjoint regions
    std::cout << "\n--- Order independence (disjoint regions) ---\n";
    {
        Topology t;
        // distant bands so Hamming neighborhoods don't bridge
        auto r = t.experiment_order_independence(0x1000, 0x5000, 16, 8);
        std::printf("  hash_order_A=%llx hash_order_B=%llx events %u/%u indep=%d\n",
            (unsigned long long)r.hash_order_A, (unsigned long long)r.hash_order_B,
            r.events_A, r.events_B, (int)r.independent);
        check(r.independent, "disjoint regions: final hash independent of A-first vs B-first order");
    }

    // Regression dual isolation
    std::cout << "\n--- Regression ---\n";
    {
        Topology t;
        auto r = t.experiment_mirror_independence(0x4242, true);
        check(r.isolation_ok, "dual isolation still holds");
        auto s = t.run_signal_adder(0x8000, 22, 11, 8);
        check(s.ok && s.result == 33, "signal adder regression");
    }

    std::cout << "\nRound 8: " << pass << " passed, " << fail << " failed\n";
    return fail ? 1 : 0;
}
