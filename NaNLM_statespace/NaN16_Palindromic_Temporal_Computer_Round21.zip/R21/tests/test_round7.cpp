#include "nan16_ptc.hpp"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <vector>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 7: dual-state mirror pairs + scale ===\n\n";

    // ----- Scale facts (exact) -----
    std::cout << "--- Scale (exact mathematics) ---\n";
    {
        std::uint32_t fixed = 0, pairs = 0;
        for (std::uint32_t i = 0; i < kAddressCount; ++i) {
            auto a = static_cast<std::uint16_t>(i);
            if (reverse16(a) == a) ++fixed;
            else if (a < reverse16(a)) ++pairs;
        }
        std::cout << "  raw addresses:     " << kAddressCount << "\n";
        std::cout << "  fixed points:      " << fixed << "\n";
        std::cout << "  mirror pairs:      " << pairs << "\n";
        std::cout << "  canonical cells:   " << (fixed + pairs) << "\n";
        check(fixed == 256, "256 fixed points");
        check(pairs == 32640, "32640 mirror pairs");
        check(fixed + pairs == 32896, "32896 canonical cells");

        // Configuration space (log10)
        // shared-state 2-bit: 2^32896
        // dual-state 2×1-bit: 2^(2*32640 + 256) = 2^65536 = 2^(2^16) interestingly full address bit-space
        double log10_shared_1bit = 32896 * std::log10(2.0);
        double log10_dual_1bit = (2.0 * 32640 + 256) * std::log10(2.0);
        double log10_dual_8bit = (2.0 * 32640 + 256) * 8 * std::log10(2.0);
        std::printf("  config space shared 1-bit/cell:  ~10^%.0f configurations\n", log10_shared_1bit);
        std::printf("  config space dual 1-bit/side:    ~10^%.0f configurations\n", log10_dual_1bit);
        std::printf("  config space dual 8-bit/side:    ~10^%.0f configurations\n", log10_dual_8bit);
        std::printf("  (for scale: atoms in observable universe ~10^80)\n");
    }

    // ----- Experiment 1: mirror independence -----
    std::cout << "\n--- Experiment 1: Mirror independence ---\n";
    {
        Topology t;
        auto r1 = t.experiment_mirror_independence(0x1234, true);
        std::printf("  touch S+: plus %08x→%08x minus %08x→%08x isol=%d\n",
            r1.plus_before, r1.plus_after, r1.minus_before, r1.minus_after, (int)r1.isolation_ok);
        check(r1.isolation_ok, "touch S+ leaves S- unchanged");

        auto r2 = t.experiment_mirror_independence(0x1234, false);
        std::printf("  touch S-: plus %08x→%08x minus %08x→%08x isol=%d\n",
            r2.plus_before, r2.plus_after, r2.minus_before, r2.minus_after, (int)r2.isolation_ok);
        check(r2.isolation_ok, "touch S- leaves S+ unchanged");

        // Fixed point can also be dual (both orientations collapse to same address, but state can still be dual)
        auto r3 = t.experiment_mirror_independence(0x8001, true);
        check(r3.isolation_ok, "fixed-point cell also supports dual isolation");
    }

    // ----- Experiment 2: complementary transitions -----
    std::cout << "\n--- Experiment 2: Complementary XOR recover ---\n";
    {
        Topology t;
        int ok = 0;
        for (int i = 0; i < 32; ++i) {
            auto r = t.experiment_complementary_xor(static_cast<std::uint16_t>(0x2000 + i), 0xDEAD0000u + i);
            if (r.recovered) ++ok;
        }
        std::printf("  recovered %d/32 complementary XORs\n", ok);
        check(ok == 32, "all complementary XOR recoveries succeed");
    }

    // ----- Bulk dual isolation -----
    std::cout << "\n--- Bulk dual isolation (1024 cells × 50 steps) ---\n";
    {
        Topology t;
        auto br = t.experiment_dual_bulk(0x3000, 1024, 50);
        std::printf("  cells=%u steps=%u isol_fail=%u comp_ok=%u comp_fail=%u\n",
            br.cells, br.steps, br.isolation_failures, br.complementary_ok, br.complementary_fail);
        check(br.isolation_failures == 0, "zero isolation failures in bulk dual walk");
        check(br.complementary_ok == 1024, "all bulk complementary recoveries ok");
    }

    // ----- How big COULD it be: width scaling sketch -----
    std::cout << "\n--- Growth path (if address width expands) ---\n";
    {
        // For n-bit addresses: fixed points = 2^{n/2} for even n under bit-reverse
        // pairs = (2^n - 2^{n/2}) / 2
        for (int n : {8, 16, 24, 32}) {
            // bit-reverse fixed points for even n: 2^(n/2)
            std::uint64_t fixed = 1ull << (n / 2);
            std::uint64_t total = 1ull << n;
            std::uint64_t pairs = (total - fixed) / 2;
            std::uint64_t cells = fixed + pairs;
            double log10_cfg = cells * std::log10(2.0); // 1-bit shared
            std::printf("  n=%2d  cells=%llu  pairs=%llu  fixed=%llu  cfg(1-bit)~10^%.0f\n",
                n, (unsigned long long)cells, (unsigned long long)pairs,
                (unsigned long long)fixed, log10_cfg);
        }
        std::cout << "  Dual-state roughly doubles payload bits per pair without new addresses.\n";
        std::cout << "  Hierarchical / paged address spaces can grow without expanding the ISA width.\n";
    }

    // ----- Regression: signal adder still works -----
    std::cout << "\n--- Regression ---\n";
    {
        Topology t;
        auto r = t.run_signal_adder(0x8000, 22, 11, 8);
        check(r.ok && r.result == 33, "signal adder 22+11=33");
    }

    std::cout << "\nRound 7: " << pass << " passed, " << fail << " failed\n";
    return fail ? 1 : 0;
}
