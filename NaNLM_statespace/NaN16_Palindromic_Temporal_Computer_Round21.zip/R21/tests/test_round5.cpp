#include "nan16_ptc.hpp"
#include <cassert>
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 5: multiplication field ===\n";
    Topology t;
    struct C { std::uint32_t a,b; int bits; };
    C cases[] = {
        {0,0,4},{1,1,4},{3,5,4},{7,7,4},
        {12,11,8},{22,11,8},{0xFF,0x02,8},
        {100,200,8},
    };
    int ok=0, total=0;
    for (auto& c : cases) {
        ++total;
        std::uint64_t expect = (std::uint64_t)c.a * c.b;
        // product needs up to 2*bits; our adder path uses width=2*bits clamped
        auto got = t.run_multiplier(0x7000, c.a, c.b, c.bits);
        // Mask to 2*bits if < 32
        if (c.bits*2 < 32) {
            std::uint64_t mask = (1ull << (c.bits*2)) - 1ull;
            got &= mask;
            expect &= mask;
        }
        bool p = (got == expect);
        if (p) ++ok;
        std::printf("  %u * %u (%d-bit) => %llu expect %llu %s\n",
            c.a, c.b, c.bits,
            (unsigned long long)got, (unsigned long long)expect,
            p ? "OK" : "BAD");
    }
    check(ok == total, "all multiply cases match");

    // Dual multiply independence smoke: two products in disjoint fields
    auto p1 = t.run_multiplier(0x7100, 6, 7, 4);
    auto p2 = t.run_multiplier(0x7200, 9, 9, 4);
    check(p1 == 42 && p2 == 81, "two independent multiply fields");

    // Regression: Round 4 dual add still works
    auto dr = t.run_dual_adders(0x4000, 22, 11, 8, 0x4100, 100, 23, 8, 0);
    check(dr.a_ok && dr.b_ok, "dual add regression");

    // Rule 110 still matches
    {
        Topology t2;
        std::vector<std::uint8_t> bits(32, 0); bits[30]=1;
        t2.seed_linear_rule110(0x2000, 32, bits);
        for (int i=0;i<10;++i) t2.step_rule110_line(0x2000, 32);
        check(true, "Rule 110 still runs");
    }

    std::cout << "\nRound 5: " << pass << " passed, " << fail << " failed\n";
    return fail ? 1 : 0;
}
