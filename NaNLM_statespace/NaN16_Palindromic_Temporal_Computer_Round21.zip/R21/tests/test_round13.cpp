#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 13: Universality path + hierarchy + self-mod + async ===\n\n";

    // --- Two-counter style ADD ---
    std::cout << "--- Two-counter machine: ADD ---\n";
    {
        Topology t;
        for (auto [x,y] : {std::pair<uint32_t,uint32_t>{0,0},{3,0},{0,5},{3,5},{10,7},{20,22}}) {
            auto r = t.experiment_twocm_add(0x1000, x, y);
            std::printf("  2CM %u+%u => %u cycles=%u ok=%d\n", x,y,r.out,r.cycles,(int)r.ok);
            check(r.ok, "2CM add");
        }
    }

    // --- Two-counter style MUL ---
    std::cout << "\n--- Two-counter machine: MUL ---\n";
    {
        Topology t;
        for (auto [x,y] : {std::pair<uint32_t,uint32_t>{0,5},{5,0},{3,4},{6,7},{2,10}}) {
            auto r = t.experiment_twocm_mul(0x2000, x, y);
            std::printf("  2CM %u*%u => %u cycles=%u ok=%d\n", x,y,r.out,r.cycles,(int)r.ok);
            check(r.ok, "2CM mul");
        }
    }

    // --- Copy via inc/dec loop ---
    std::cout << "\n--- Two-counter COPY ---\n";
    {
        Topology t;
        for (uint32_t x : {0u,1u,5u,12u}) {
            auto r = t.experiment_twocm_copy(0x3000, x);
            std::printf("  copy %u => %u ok=%d\n", x, r.out, (int)r.ok);
            check(r.ok, "2CM copy");
        }
    }

    // --- Self-modifying ---
    std::cout << "\n--- Self-modifying program ---\n";
    {
        Topology t;
        auto s = t.experiment_self_modifying(0x4000);
        std::printf("  out=%u patched=%d ok=%d\n", s.out, (int)s.patched, (int)s.ok);
        check(s.patched, "program memory was patched");
        check(s.ok, "self-mod program OUT=99 after patch");
    }

    // --- Hierarchy ---
    std::cout << "\n--- Hierarchical pages ---\n";
    {
        Topology t;
        auto h = t.experiment_hierarchy(0x5000, 0x5100, 0x5200);
        std::printf("  page0=%u page1=%u ok=%d\n", h.page0_out, h.page1_out, (int)h.ok);
        check(h.ok, "page0 XOR=10, page1 portal+1=11");
    }

    // --- Async dual VMs (no global lockstep required) ---
    std::cout << "\n--- Async dual VMs (schedule independence) ---\n";
    {
        Topology t;
        auto a = t.experiment_async_dual_vms(0x6000, 0x6100);
        std::printf("  order1=%d order2=%d match=%d outs %u,%u\n",
            (int)a.order1_ok,(int)a.order2_ok,(int)a.match, a.out_a, a.out_b);
        check(a.order1_ok, "A-heavy interleave correct");
        check(a.order2_ok, "B-heavy interleave correct");
        check(a.match, "both schedules agree (no global clock needed)");
    }

    // --- Resource compare ---
    std::cout << "\n--- Resource compare (2CM mul vs host ops) ---\n";
    {
        Topology t;
        auto a = t.experiment_resource_compare(6, 7);
        std::printf("  6*7 vm_cycles=%u host_inner_adds=%u same=%d\n",
            a.vm_cycles, a.host_ref_ops, (int)a.same_answer);
        check(a.same_answer, "VM mul matches reference product");
        check(a.vm_cycles > 0, "VM performed measurable work");
    }

    // --- R12 regression ---
    std::cout << "\n--- R12 baseline regression ---\n";
    {
        Topology t;
        auto s = t.experiment_vm_suite();
        check(s.passed == s.programs && s.programs >= 10, "R12 suite still green");
    }

    std::cout << "\n========================================\n"
              << "Round 13: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
