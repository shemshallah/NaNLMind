#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 19: Harder cognitive stress tests ===\n\n";

    std::cout << "--- Deep ISA chains ---\n";
    {
        Topology t;
        auto H = t.experiment_deep_isa_chain(8);
        std::printf("  max_depth=%d mid_exc=%d leaf_exc=%d\n",
            H.max_depth, (int)H.exception_at_mid, (int)H.exception_at_leaf);
        for (int d = 1; d <= 8; ++d)
            std::printf("  depth %d: %s\n", d, H.depths[d] ? "OK" : "FAIL");
        check(H.max_depth >= 6, "ISA inheritance depth ≥ 6");
        check(H.max_depth >= 8, "ISA inheritance depth 8");
        check(H.exception_at_mid, "mid-chain exception blocks inheritance");
        check(H.exception_at_leaf, "leaf exception blocks inheritance");
    }

    std::cout << "\n--- Nested exceptions ---\n";
    {
        Topology t;
        auto N = t.experiment_nested_exceptions();
        check(N.leaf_exception_wins, "emperor→penguin→¬fly");
        check(N.mid_exception_wins, "individual→species¬fly");
        check(N.no_exception_inherits, "eagle inherits bird CAN fly");
        check(N.all_ok, "nested exception suite");
    }

    std::cout << "\n--- Assert order invariance ---\n";
    {
        Topology t;
        auto O = t.experiment_assert_order_invariance(120);
        std::printf("  probes=%d mismatches=%d\n", O.probes, O.mismatches);
        check(O.same_answers, "forward vs reverse assert order → identical answers");
    }

    std::cout << "\n--- Learning under conflict ---\n";
    {
        Topology t;
        auto C = t.experiment_learning_under_conflict(50);
        std::printf("  proposals=%d contested=%d no_false_yes=%d\n",
            C.proposals, (int)C.stays_contested, (int)C.no_false_yes);
        check(C.stays_contested && C.no_false_yes, "50 rounds of CAN vs CANNOT stay contested");
    }

    std::cout << "\n--- Mega context (2000 facts) ---\n";
    {
        Topology t;
        auto M = t.experiment_mega_context(2000, 50);
        std::printf("  facts=%d acc=%.4f ms/query=%.4f\n", M.facts, M.accuracy, M.ms_per_query);
        check(M.ok_99, "2000 facts, ≥99% probe accuracy");
        check(M.ms_per_query < 50.0, "query latency under 50ms (local)");
    }

    std::cout << "\n--- Resonance interference ---\n";
    {
        Topology t;
        auto I = t.experiment_resonance_interference();
        std::printf("  E_mid=%.4f E_quiet=%.4f both=%d\n",
            I.energy_mid, I.energy_quiet, (int)I.reached_both);
        check(I.reached_both, "both sources retain energy");
        check(I.constructive_mid, "mid lattice receives wave energy");
    }

    std::cout << "\n--- Head committee ---\n";
    {
        Topology t;
        auto C = t.experiment_head_committee(7, 4);
        check(C.contested && C.committee_ok, "7 yes + 4 no → contested, not false consensus");
        auto Y = t.experiment_head_committee(5, 0);
        check(Y.consensus_yes && Y.committee_ok, "unanimous yes → consensus yes");
    }

    std::cout << "\n--- Hard cognition suite ---\n";
    {
        Topology t;
        auto S = t.experiment_hard_cognition();
        std::printf("  %d/%d chain_depth=%d mega_acc=%.3f\n",
            S.passed, S.tests, S.chain.max_depth, S.mega.accuracy);
        check(S.passed == S.tests, "hard suite all green");
    }

    std::cout << "\n--- R18 regression ---\n";
    {
        Topology t;
        auto S = t.experiment_deep_cognition();
        check(S.passed == S.tests, "R18 deep cognition still green");
    }

    std::cout << "\n========================================\n"
              << "Round 19: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
