// Round 15: continuity of state, matrix-of-heads in mirror-paired cells, honest specialization experiment.
#include "continuity.hpp"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <map>
#include <set>

using namespace nan16;

static int g_pass = 0, g_fail = 0;
static void check(const char* name, bool ok) {
    std::printf("  %s: %s\n", ok ? "PASS" : "FAIL", name);
    ok ? ++g_pass : ++g_fail;
}
static double now_ms() {
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

// ------------------------------------------------------------- task world (6 task types over 256 features)
constexpr int kTasks = 6;
struct World {
    std::vector<std::vector<unsigned>> core;
    explicit World(double overlap) {
        std::uint64_t s = 777;
        std::vector<unsigned> shared;
        while (shared.size() < 32) { unsigned f = splitmix(s) & 255; if (std::find(shared.begin(), shared.end(), f) == shared.end()) shared.push_back(f); }
        unsigned n_shared = (unsigned)(32 * overlap);
        for (int t = 0; t < kTasks; ++t) {
            std::vector<unsigned> c(shared.begin(), shared.begin() + n_shared);
            while (c.size() < 32) { unsigned f = splitmix(s) & 255; if (std::find(c.begin(), c.end(), f) == c.end()) c.push_back(f); }
            core.push_back(c);
        }
    }
    std::vector<std::uint8_t> sample(int t, std::uint64_t& rng) const {
        std::uint16_t val[256] = {0};
        for (unsigned f : core[(std::size_t)t]) if ((splitmix(rng) % 100) < 85) val[f] = 4096;
        for (int k = 0; k < 6; ++k) { unsigned f = splitmix(rng) & 255; if (!val[f]) val[f] = 2048; }
        ByteWriter w; std::uint16_t n = 0;
        for (unsigned f = 0; f < 256; ++f) if (val[f]) ++n;
        w.u16(n);
        for (unsigned f = 0; f < 256; ++f) if (val[f]) { w.u16((std::uint16_t)f); w.u16(val[f]); }
        return w.b;
    }
};

struct Metrics { double mi = 0, null_mi = 0, purity = 0; int used = 0; };
static double mutual_info(const std::vector<std::array<double, kTasks>>& c) {
    double tot = 0; std::array<double, kTasks> pt{}; std::vector<double> ph(c.size());
    for (std::size_t h = 0; h < c.size(); ++h) for (int t = 0; t < kTasks; ++t) { tot += c[h][(std::size_t)t]; ph[h] += c[h][(std::size_t)t]; pt[(std::size_t)t] += c[h][(std::size_t)t]; }
    double mi = 0;
    for (std::size_t h = 0; h < c.size(); ++h) for (int t = 0; t < kTasks; ++t) {
        double p = c[h][(std::size_t)t] / tot; if (p <= 0) continue;
        mi += p * std::log2(p / ((ph[h] / tot) * (pt[(std::size_t)t] / tot)));
    }
    return mi;
}
static Metrics analyse(const std::vector<int>& win, const std::vector<int>& lab, std::size_t from) {
    std::vector<std::array<double, kTasks>> c(kHeads); for (auto& r : c) r.fill(0);
    for (std::size_t i = from; i < win.size(); ++i) c[(std::size_t)win[i]][(std::size_t)lab[i]] += 1;
    Metrics m; m.mi = mutual_info(c);
    double tot = 0, mx = 0;
    for (auto& r : c) { double s = 0, b = 0; for (double v : r) { s += v; b = std::max(b, v); } if (s > 0) ++m.used; tot += s; mx += b; }
    m.purity = mx / tot;
    std::uint64_t rs = 4242; double acc = 0; int reps = 40;
    for (int k = 0; k < reps; ++k) {
        std::vector<int> sh(lab.begin() + (long)from, lab.end());
        for (std::size_t i = sh.size(); i > 1; --i) std::swap(sh[i - 1], sh[splitmix(rs) % i]);
        std::vector<std::array<double, kTasks>> cc(kHeads); for (auto& r : cc) r.fill(0);
        for (std::size_t i = from; i < win.size(); ++i) cc[(std::size_t)win[i]][(std::size_t)sh[i - from]] += 1;
        acc += mutual_info(cc);
    }
    m.null_mi = acc / reps;
    return m;
}

struct Run { Machine m; Ledger L; std::vector<int> win, lab; std::vector<std::vector<std::uint8_t>> events; };
static Run run_world(HeadMode mode, double overlap, std::uint64_t order_seed, std::size_t steps) {
    Machine m; m.mode = mode;
    Ledger L(m, 500);
    Run r{m, L, {}, {}, {}};
    World w(overlap);
    std::uint64_t rng = order_seed;
    for (std::size_t i = 0; i < steps; ++i) {
        int t = (int)(splitmix(rng) % kTasks);
        auto ev = w.sample(t, rng);
        int win = -1;
        r.L.append(r.m, EvType::HeadInput, ev, &win);
        r.win.push_back(win); r.lab.push_back(t); r.events.push_back(ev);
    }
    return r;
}

int main() {
    std::printf("=== Round 15: Continuity of State ===\n");

    // ---------------------------------------------------------------- 1. SHA-256 known-answer tests
    std::printf("\n--- SHA-256 ---\n");
    check("SHA256(\"abc\")", hex(Sha256::of("abc")) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    check("SHA256(\"\")", hex(Sha256::of("")) == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
    check("SHA256(448-bit msg, 2-block)", hex(Sha256::of("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq")) ==
          "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");

    // ---------------------------------------------------------------- 2. mirror pairing == matrix transpose
    std::printf("\n--- Topology is a symmetric 256x256 matrix ---\n");
    {
        bool mirror_is_transpose = true, diag_is_palindrome = true;
        int palins = 0;
        std::set<std::uint16_t> canon_cells;
        for (unsigned a = 0; a < 256; ++a) for (unsigned b = 0; b < 256; ++b) {
            auto ad = addr_of(a, b);
            if (reverse16(ad) != addr_of(b, a)) mirror_is_transpose = false;
            if ((a == b) != is_bit_palindrome(ad)) diag_is_palindrome = false;
            if (is_bit_palindrome(ad)) ++palins;
            canon_cells.insert(canonical_of(ad));
        }
        check("reverse16(addr(a,b)) == addr(b,a) for all 65536 pairs", mirror_is_transpose);
        check("bit-palindromic fixed points == the 256 diagonal cells", diag_is_palindrome && palins == 256);
        std::printf("  canonical cells=%zu  mirror pairs=%zu  C(256,2)=%d\n", canon_cells.size(), canon_cells.size() - 256, 256 * 255 / 2);
        check("32,640 mirror pairs == C(256,2) (identity, not coincidence)", canon_cells.size() - 256 == 32640);

        Topology T;
        std::uint64_t s = 99;
        std::vector<std::uint32_t> want(65536);
        for (unsigned a = 0; a < 256; ++a) for (unsigned b = 0; b < 256; ++b) { want[a * 256 + b] = (std::uint32_t)splitmix(s); mat_ref(T, a, b) = want[a * 256 + b]; }
        // diagonal aux is reserved for per-head state; clobber it and re-check W is intact
        for (unsigned a = 0; a < 256; ++a) head_load_ref(T, a) = 0xDEADBEEF;
        bool rt = true;
        for (unsigned a = 0; a < 256; ++a) for (unsigned b = 0; b < 256; ++b) if (mat_get(T, a, b) != want[a * 256 + b]) rt = false;
        check("arbitrary ASYMMETRIC 256x256 matrix round-trips through 32,896 cells (S+ = W[a][b], S- = W[b][a])", rt);
    }

    // ---------------------------------------------------------------- 3. Blind spots of Topology::state_hash()
    std::printf("\n--- Blind spots in R14's state_hash() ---\n");
    {
        Topology A, B;
        A.at_canonical(0x0123).state = 5; A.at_canonical(0x0123).aux = 9;
        B.at_canonical(0x0123).state = 9; B.at_canonical(0x0123).aux = 5;
        check("old state_hash collides when S+ and S- rails are swapped", A.state_hash() == B.state_hash());
        check("full_digest distinguishes them", full_digest(A) != full_digest(B));

        Topology P, Q;
        P.cog_clear(); Q.cog_clear();
        P.cog_assert(Topology::C_PENGUIN, Topology::R_ISA, Topology::C_BIRD);
        P.cog_assert(Topology::C_BIRD, Topology::R_CAN, Topology::C_FLY);
        Q.cog_assert(Topology::C_PENGUIN, Topology::R_ISA, Topology::C_BIRD);
        Q.cog_assert(Topology::C_BIRD, Topology::R_CAN, Topology::C_WINGS);   // different knowledge, same counters
        bool same_old = P.state_hash() == Q.state_hash();
        bool diff_answer = P.cog_query(Topology::C_PENGUIN, Topology::R_CAN, Topology::C_FLY).found !=
                           Q.cog_query(Topology::C_PENGUIN, Topology::R_CAN, Topology::C_FLY).found;
        check("two minds that answer differently have IDENTICAL old state_hash (cog_kb_ not hashed)", same_old && diff_answer);
        check("full_digest distinguishes them", full_digest(P) != full_digest(Q));
    }

    // ---------------------------------------------------------------- 4. Ledger: determinism, replay, checkpoint
    std::printf("\n--- Hash-chained ledger ---\n");
    const std::size_t N = 3000;
    double t0 = now_ms();
    Run base = run_world(HeadMode::Inhibit, 0.0, 1001, N);
    double t1 = now_ms();
    std::printf("  %zu transitions in %.0f ms (%.1f us/transition incl. SHA-256 chain + %zu checkpoints)\n",
                N, t1 - t0, (t1 - t0) * 1000.0 / (double)N, base.L.size() / 500);
    std::printf("  CHAIN_HEAD=%s\n", hex(base.L.head()).c_str());
    std::printf("  STATE_DIGEST=%s\n", hex(full_digest(base.m.T)).c_str());
    {
        Machine fresh; fresh.mode = HeadMode::Inhibit;
        auto rep = base.L.replay_verify(fresh, &base.L.head());
        check("replay from genesis on a fresh Topology reproduces every delta, checkpoint and link", rep.ok);
        check("replayed final state digest == live final state digest", rep.final_state == full_digest(base.m.T));
        Machine wrong; wrong.mode = HeadMode::WTA;
        auto rep2 = base.L.replay_verify(wrong);
        check("different transition function (mode) => different genesis => rejected", !rep2.ok && rep2.first_bad == -1);
        Machine c = base.m; c.rebuild_caches();
        check("derived caches (norm2, total_wins) equal their recomputation", c.norm2 == base.m.norm2 && c.total_wins == base.m.total_wins);
    }

    // ---------------------------------------------------------------- 5. Tamper evidence
    std::printf("\n--- Tamper evidence ---\n");
    {
        Machine fresh; fresh.mode = HeadMode::Inhibit;
        Ledger tampered = base.L;
        tampered.entries()[1234].payload[5] ^= 0x01;
        auto r1 = tampered.replay_verify(fresh);
        std::printf("  flip 1 bit of event 1234 -> first_bad=%ld (%s)\n", r1.first_bad, r1.why.c_str());
        check("event edit located at exactly the edited index", !r1.ok && r1.first_bad == 1234);

        Ledger t2 = base.L; t2.entries()[777].delta[0] ^= 0xFF;
        auto r2 = t2.replay_verify(fresh);
        check("delta edit located at exactly the edited index", !r2.ok && r2.first_bad == 777);

        Ledger t3 = base.L; t3.entries()[2000].chain[31] ^= 1;
        auto r3 = t3.replay_verify(fresh);
        check("chain-link edit located at exactly the edited index", !r3.ok && r3.first_bad == 2000);

        // consistent forgery: rewrite history from event k onward and recompute everything
        Machine fm; fm.mode = HeadMode::Inhibit; Ledger forged(fm, 500);
        for (std::size_t i = 0; i < base.events.size(); ++i) {
            auto ev = base.events[i];
            if (i == 1234) ev[5] ^= 0x01;
            forged.append(fm, EvType::HeadInput, ev);
        }
        Machine f2; f2.mode = HeadMode::Inhibit;
        bool self_consistent = forged.replay_verify(f2).ok;
        bool caught = !forged.replay_verify(f2, &base.L.head()).ok;
        check("a fully recomputed forgery is internally consistent...", self_consistent);
        check("...but is caught against the pinned chain head (identity = head)", caught && forged.head() != base.L.head());
    }

    // ---------------------------------------------------------------- 6. Migration: "all physical resources change"
    std::printf("\n--- Substrate migration (checkpoint -> new Topology -> continue) ---\n");
    {
        Machine A; A.mode = HeadMode::Inhibit; Ledger LA(A, 500);
        Machine B; B.mode = HeadMode::Inhibit; Ledger LB(B, 500);
        for (std::size_t i = 0; i < 1500; ++i) { LA.append(A, EvType::HeadInput, base.events[i]); LB.append(B, EvType::HeadInput, base.events[i]); }
        auto bytes = checkpoint_bytes(B.T);
        Machine C; C.mode = HeadMode::Inhibit;               // brand-new Topology: "new hardware"
        restore_bytes(C.T, bytes); C.rebuild_caches();
        check("restored state digest == source state digest", full_digest(C.T) == full_digest(B.T));
        for (std::size_t i = 1500; i < N; ++i) { LA.append(A, EvType::HeadInput, base.events[i]); LB.append(C, EvType::HeadInput, base.events[i]); }
        check("run continued on the new substrate lands on the SAME chain head", LA.head() == LB.head() && LA.head() == base.L.head());
        check("...and the same final state digest", full_digest(A.T) == full_digest(C.T));
        auto bad = bytes; bad[bad.size() / 2] ^= 1;
        Machine D; D.mode = HeadMode::Inhibit; restore_bytes(D.T, bad);
        check("a single corrupted checkpoint byte is visible in the digest", full_digest(D.T) != full_digest(B.T));
    }

    // ---------------------------------------------------------------- 7. Branches: workspaces, not minds
    std::printf("\n--- Branches as transactions ---\n");
    {
        Machine m = base.m; Ledger L = base.L;
        World w(0.0); std::uint64_t rng = 31337;
        Digest before = full_digest(m.T); std::size_t n0 = L.size();

        auto ws = L.fork(m);
        for (int i = 0; i < 40; ++i) ws.run(EvType::HeadInput, w.sample(2, rng));
        Digest ws_digest = full_digest(ws.m.T);
        check("workspace state diverges from main", ws_digest != before);
        check("main untouched while the branch runs", full_digest(m.T) == before);
        check("abort: appended as ONE history entry", L.abort(m, ws) && L.size() == n0 + 1);
        check("abort: main state unchanged (counterfactual discarded)", full_digest(m.T) == before);
        check("abort: log records the digest of the discarded counterfactual == workspace digest", L.entries().back().delta == ws_digest);
        Machine fr; fr.mode = HeadMode::Inhibit;
        check("history with an abort still replays (counterfactual re-derived & verified)", L.replay_verify(fr, &L.head()).ok);

        auto ws2 = L.fork(m); rng = 31337;
        for (int i = 0; i < 40; ++i) ws2.run(EvType::HeadInput, w.sample(2, rng));
        Digest ws2_digest = full_digest(ws2.m.T);
        check("commit: main becomes exactly the workspace result", L.commit(m, ws2) && full_digest(m.T) == ws2_digest);
        check("history with a commit replays", L.replay_verify(fr, &L.head()).ok);

        auto stale = L.fork(m);
        stale.run(EvType::HeadInput, w.sample(1, rng));
        Digest pre_head = L.head();
        L.append(m, EvType::HeadInput, w.sample(0, rng));
        Digest moved_state = full_digest(m.T);
        check("stale workspace cannot commit (must rebase) -- no permanent competing minds", !L.commit(m, stale) && full_digest(m.T) == moved_state);
        check("second writer holding a stale head cannot append (no fork of history)", !L.append(m, EvType::HeadInput, w.sample(0, rng), nullptr, &pre_head));
    }

    // ---------------------------------------------------------------- 8. R14 cognition rides the same ledger
    std::printf("\n--- R14 knowledge events on the same chain ---\n");
    {
        Machine m; Ledger L(m, 0);
        auto ca = [&](unsigned s, unsigned r, unsigned o) { ByteWriter w; w.u16((std::uint16_t)s); w.u8((std::uint8_t)r); w.u16((std::uint16_t)o); L.append(m, EvType::CogAssert, w.b); };
        m.T.cog_clear();
        ca(Topology::C_EAGLE, Topology::R_ISA, Topology::C_BIRD);
        ca(Topology::C_PENGUIN, Topology::R_ISA, Topology::C_BIRD);
        ca(Topology::C_BIRD, Topology::R_CAN, Topology::C_FLY);
        ca(Topology::C_PENGUIN, Topology::R_CANNOT, Topology::C_FLY);
        Machine fr; fr.T.cog_clear();
        auto rep = L.replay_verify(fr);
        check("knowledge assertions replay deterministically", rep.ok);
        check("penguin cannot fly (exception) on replayed machine", !fr.T.cog_query(Topology::C_PENGUIN, Topology::R_CAN, Topology::C_FLY).yes);
        check("history contains who-asserted-what in order (4 entries, chain advances)", L.size() == 4);
    }

    // ---------------------------------------------------------------- 9. The R15 specialization experiment
    std::printf("\n--- R15: do 256 identical heads specialize? (6 task types, max MI = %.2f bits) ---\n", std::log2((double)kTasks));
    std::printf("  heads start IDENTICAL (all-zero matrix). tie-break = hash of causal history. every run is chain-verified.\n");
    struct Cond { const char* name; HeadMode mode; };
    Cond conds[] = {{"WTA, no inhibition", HeadMode::WTA}, {"lateral inhibition", HeadMode::Inhibit},
                    {"frozen (no learning)", HeadMode::Frozen}, {"random routing (learns)", HeadMode::RandomRoute}};
    std::map<std::string, double> mi_by;
    for (double overlap : {0.0, 0.5}) {
        std::printf("  task overlap = %.1f\n  %-26s %7s %7s %8s %6s\n", overlap, "condition", "MI", "null", "purity", "heads");
        for (auto& c : conds) {
            double mi = 0, nl = 0, pu = 0, us = 0; int seeds = 3; bool verified = true;
            for (int sd = 0; sd < seeds; ++sd) {
                Run r = run_world(c.mode, overlap, 5000 + (std::uint64_t)sd, 3000);
                auto me = analyse(r.win, r.lab, r.win.size() / 2);
                mi += me.mi; nl += me.null_mi; pu += me.purity; us += me.used;
                if (sd == 0) { Machine fr; fr.mode = c.mode; verified = r.L.replay_verify(fr, &r.L.head()).ok; }
            }
            std::printf("  %-26s %7.2f %7.2f %8.2f %6.0f %s\n", c.name, mi / seeds, nl / seeds, pu / seeds, us / seeds, verified ? "" : "(REPLAY FAIL)");
            if (!verified) ++g_fail;
            mi_by[std::string(c.name) + (overlap > 0 ? "|hard" : "|easy")] = mi / seeds;
            mi_by[std::string(c.name) + "|null" + (overlap > 0 ? "|hard" : "|easy")] = nl / seeds;
        }
    }
    for (const char* k : {"easy", "hard"}) {
        std::string K = std::string("|") + k;
        check((std::string("inhibition specializes far above WTA [") + k + "]").c_str(), mi_by["lateral inhibition" + K] > mi_by["WTA, no inhibition" + K] + 0.5);
        check((std::string("inhibition specializes far above its shuffled null [") + k + "]").c_str(), mi_by["lateral inhibition" + K] > mi_by["lateral inhibition|null" + K] + 1.0);
        check((std::string("random routing is indistinguishable from null [") + k + "]").c_str(), std::fabs(mi_by["random routing (learns)" + K] - mi_by["random routing (learns)|null" + K]) < 0.2);
    }

    std::printf("\n========================================\nRound 15: %d passed, %d failed\n========================================\n", g_pass, g_fail);
    return g_fail == 0 ? 0 : 1;
}
