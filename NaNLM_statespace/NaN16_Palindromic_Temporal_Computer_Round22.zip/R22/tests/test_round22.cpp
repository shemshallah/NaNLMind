#include "nan16_ptc.hpp"
#include <cstdio>
#include <iostream>
using namespace nan16;

static int pass=0, fail=0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

int main() {
    std::cout << "=== Round 22: HARDER logic puzzles ===\n\n";

    std::cout << "── 1. \"We are both knaves\" ──\n";
    {
        Topology t;
        auto R = t.experiment_puzzle_both_knaves();
        std::printf("  models=%d A=%s B=%s\n", R.models,
            R.a_type==1?"knight":"knave", R.b_type==1?"knight":"knave");
        check(R.solved && R.a_type==0 && R.b_type==1, "A knave, B knight (unique)");
    }

    std::cout << "\n── 2. Three islanders ──\n";
    {
        Topology t;
        auto R = t.experiment_puzzle_three_islanders();
        std::printf("  unique models=%d A=%d B=%d\n", R.models, R.a_type, R.b_type);
        check(R.solved && R.models==1, "unique consistent assignment");
    }

    std::cout << "\n── 3. Einstein subset (3 houses) ──\n";
    {
        Topology t;
        auto E = t.experiment_puzzle_einstein3();
        std::printf("  models=%d brit@%d dogs@%d green@%d\n",
            E.models, E.brit_house, E.dog_house, E.green_house);
        check(E.solved && E.models>=1, "constraint set satisfiable");
        check(E.brit_house == E.green_house || E.brit_house != E.green_house, "houses assigned");
        // Green left of white implies green is 0 or 1
        check(E.green_house >= 0 && E.green_house <= 1, "green left of white");
    }

    std::cout << "\n── 4. Fork in the road ──\n";
    {
        Topology t;
        auto F = t.experiment_puzzle_fork();
        check(F.solved && !F.take_path_if_yes, "YES answer ⇒ do not take that path");
    }

    std::cout << "\n── 5. Exactly one knight ──\n";
    {
        Topology t;
        auto R = t.experiment_puzzle_xor_census();
        std::printf("  models=%d A=%d B=%d\n", R.models, R.a_type, R.b_type);
        check(R.solved && R.models==1, "exactly one knight unique model");
    }

    std::cout << "\n── 6. Grid inequalities ──\n";
    {
        Topology t;
        auto G = t.experiment_puzzle_grid4();
        std::printf("  solutions=%d values=%d %d %d %d\n",
            G.solutions, G.values[0], G.values[1], G.values[2], G.values[3]);
        check(G.solved && G.solutions>=1, "at least one grid solution");
        if (G.solved) {
            check(G.values[0] < G.values[1], "A < B");
            check(G.values[2] > G.values[3], "C > D");
            check(G.values[1] != 3, "B ≠ 3");
        }
    }

    std::cout << "\n── 7. Nested speech ──\n";
    {
        Topology t;
        auto R = t.experiment_puzzle_nested_speech();
        std::printf("  models=%d A=%d B=%d\n", R.models, R.a_type, R.b_type);
        check(R.solved && R.models>=1, "nested \"B says I am knave\" consistent");
    }

    std::cout << "\n── Hard puzzle suite ──\n";
    {
        Topology t;
        auto S = t.experiment_hard_puzzles();
        std::printf("  %d/%d\n", S.passed, S.tests);
        check(S.passed == S.tests, "ALL HARD PUZZLES GREEN");
    }

    std::cout << "\n── R21 formal regression ──\n";
    {
        Topology t;
        auto S = t.experiment_formal_suite();
        check(S.passed == S.tests, "R21 formal still green");
    }

    std::cout << "\n========================================\n"
              << "Round 22: " << pass << " passed, " << fail << " failed\n"
              << "========================================\n";
    return fail ? 1 : 0;
}
