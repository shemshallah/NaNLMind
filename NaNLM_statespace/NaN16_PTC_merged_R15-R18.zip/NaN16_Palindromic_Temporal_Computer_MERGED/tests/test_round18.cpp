// Round 18: Transposition Correspondence + matrix resonance + sequence memory.
// Everything is stored in / read from real Topology cells (S+ / S- of dual cells).
#include "nan16_ptc.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <random>
#include <vector>
using namespace nan16;

static int pass = 0, fail = 0;
static void check(bool c, const char* m) {
    if (c) { ++pass; std::cout << "  PASS: " << m << "\n"; }
    else   { ++fail; std::cout << "  FAIL: " << m << "\n"; }
}

static std::uint8_t rev8(std::uint8_t x) {
    std::uint8_t y = 0;
    for (int i = 0; i < 8; ++i) { y = (std::uint8_t)((y << 1) | (x & 1)); x >>= 1; }
    return y;
}
static std::uint16_t addr(int a, int b) { return (std::uint16_t)((a << 8) | rev8((std::uint8_t)b)); }
static std::uint32_t f2u(float f) { std::uint32_t u; std::memcpy(&u, &f, 4); return u; }
static float u2f(std::uint32_t u) { float f; std::memcpy(&f, &u, 4); return f; }

// W[a][b] lives at address addr(a,b): S+ if that address is canonical, else S-.
static void store_w(Topology& t, int a, int b, float v) {
    std::uint16_t ad = addr(a, b), c = canonical_of(ad);
    Cell& cell = t.at_canonical(c);
    if (is_bit_palindrome(c)) { cell.state = f2u(v); return; }
    cell.set_dual(true);
    if (ad == c) cell.set_s_plus(f2u(v)); else cell.set_s_minus(f2u(v));
}
static float load_w(const Topology& t, int a, int b) {
    std::uint16_t ad = addr(a, b), c = canonical_of(ad);
    const Cell& cell = t.at_canonical(c);
    if (is_bit_palindrome(c)) return u2f(cell.state);
    return u2f(ad == c ? cell.s_plus() : cell.s_minus());
}
static void store_matrix(Topology& t, const std::vector<float>& W) {
    for (int a = 0; a < 256; ++a) for (int b = 0; b < 256; ++b) store_w(t, a, b, W[a * 256 + b]);
}
static std::vector<float> load_matrix(const Topology& t) {
    std::vector<float> W(65536);
    for (int a = 0; a < 256; ++a) for (int b = 0; b < 256; ++b) W[a * 256 + b] = load_w(t, a, b);
    return W;
}


static std::vector<float> randn_matrix(std::mt19937& rng) {
    std::normal_distribution<float> nd(0.f, 1.f);
    std::vector<float> W(65536);
    for (auto& w : W) w = nd(rng);
    return W;
}
// W = sym*S + asym*A (S, A from a random matrix), scaled to spectral scale ~1
static std::vector<float> mix(const std::vector<float>& R, float sym, float asym) {
    std::vector<float> W(65536);
    for (int a = 0; a < 256; ++a) for (int b = 0; b < 256; ++b) {
        float r = R[a * 256 + b], rt = R[b * 256 + a];
        W[a * 256 + b] = (sym * (r + rt) / 2 + asym * (r - rt) / 2) / 16.f; // /sqrt(256)
    }
    return W;
}
struct Dyn { double c1, c2; };
// Power-iterate x <- Wx (normalised). c1 = <x_t,x_{t+1}>, c2 = <x_t,x_{t+2}> averaged over the late phase.
// Dominant real eigenvalue: c2 -> +1 (c1 -> +-1). Dominant imaginary pair: c1 -> 0, c2 -> -1 (period-4 rotation).
static Dyn run_linear(const std::vector<float>& W, std::mt19937& rng, int T) {
    std::normal_distribution<double> nd(0, 1);
    auto step = [&](const std::vector<double>& x) {
        std::vector<double> y(256); double n = 0;
        for (int a = 0; a < 256; ++a) { double s = 0; for (int b = 0; b < 256; ++b) s += W[a * 256 + b] * x[b]; y[a] = s; n += s * s; }
        n = std::sqrt(n); for (auto& v : y) v /= n; return y; };
    auto dot = [](const std::vector<double>& u, const std::vector<double>& v) { double s = 0; for (int i = 0; i < 256; ++i) s += u[i] * v[i]; return s; };
    std::vector<double> x(256); for (auto& v : x) v = nd(rng);
    double n0 = std::sqrt(dot(x, x)); for (auto& v : x) v /= n0;
    for (int t = 0; t < T; ++t) x = step(x);
    double c1 = 0, c2 = 0; int K = 40;
    for (int k = 0; k < K; ++k) { auto x1 = step(x), x2 = step(x1); c1 += dot(x, x1); c2 += dot(x, x2); x = x1; }
    return {c1 / K, c2 / K};
}

static float sgn(float v) { return v >= 0 ? 1.f : -1.f; }
// Store sequence p_0..p_{P-1} (cyclic). asym: W=sum p_{m+1} p_m^T ; sym: W=sum p_m p_m^T
static int sequence_recall(std::mt19937& rng, int P, bool asym, float* mean_overlap) {
    std::vector<std::vector<float>> p(P, std::vector<float>(256));
    for (auto& v : p) for (auto& e : v) e = (rng() & 1) ? 1.f : -1.f;
    std::vector<float> W(65536, 0.f);
    for (int m = 0; m < P; ++m) {
        const auto& nx = p[(m + 1) % P]; const auto& cur = p[m];
        for (int a = 0; a < 256; ++a) for (int b = 0; b < 256; ++b)
            W[a * 256 + b] += (asym ? nx[a] : cur[a]) * cur[b] / 256.f;
    }
    Topology t; store_matrix(t, W);
    std::vector<float> L = load_matrix(t);          // run dynamics from the cells
    std::vector<float> x = p[0], y(256);
    int good = 0; double ov = 0;
    for (int step = 1; step <= P; ++step) {
        for (int a = 0; a < 256; ++a) {
            float s = 0; for (int b = 0; b < 256; ++b) s += L[a * 256 + b] * x[b];
            y[a] = sgn(s);
        }
        x = y;
        const auto& tgt = p[step % P];
        int agree = 0; for (int a = 0; a < 256; ++a) agree += (x[a] == tgt[a]);
        ov += agree / 256.0;
        if (agree == 256) ++good;
    }
    if (mean_overlap) *mean_overlap = (float)(ov / P);
    return good;
}

int main() {
    std::mt19937 rng(18);
    std::cout << "=== Round 18: NaN16 Transposition Correspondence ===\n\n";

    std::cout << "--- Theorem ---\n";
    {
        bool ok = true; int fixed = 0, pairs = 0;
        for (int a = 0; a < 256; ++a) for (int b = 0; b < 256; ++b) {
            std::uint16_t x = addr(a, b);
            if (reverse16(x) != addr(b, a)) ok = false;
            if (is_bit_palindrome(x)) { ++fixed; if (a != b) ok = false; }
            else if (x < reverse16(x)) ++pairs;
        }
        check(ok, "reverse16(addr(a,b)) == addr(b,a) for all 65536 cells");
        check(fixed == 256 && pairs == 32640, "256 diagonal fixed points + 32640 mirror pairs");
        Topology t;
        bool shared = true;
        for (int a = 0; a < 256; ++a) for (int b = a + 1; b < 256; ++b)
            if (&t.at_address(addr(a, b)) != &t.at_address(addr(b, a))) shared = false;
        check(shared, "W[a][b] and W[b][a] share one physical cell");
    }

    std::cout << "\n--- Storage round-trip in real cells (S+/S-) ---\n";
    {
        auto R = randn_matrix(rng);
        { Topology t; store_matrix(t, R); check(load_matrix(t) == R, "dense signed asymmetric matrix exact"); }
        std::vector<float> S(65536, 0.f);
        for (int i = 0; i < 65536; ++i) if (rng() % 50 == 0) S[i] = R[i];
        { Topology t; store_matrix(t, S); check(load_matrix(t) == S, "sparse (2%) matrix exact"); }
        std::vector<float> A(65536);
        for (int a = 0; a < 256; ++a) for (int b = 0; b < 256; ++b) A[a * 256 + b] = R[a * 256 + b] - R[b * 256 + a];
        { Topology t; store_matrix(t, A); auto L = load_matrix(t);
          bool anti = true;
          for (int a = 0; a < 256; ++a) for (int b = 0; b < 256; ++b) if (L[a * 256 + b] != -L[b * 256 + a]) anti = false;
          check(L == A && anti, "antisymmetric matrix exact, S- == -S+ off diagonal"); }
        { Topology t; store_matrix(t, R);
          // overwrite one direction only; reverse direction must be untouched
          float before = load_w(t, 7, 200); store_w(t, 200, 7, 123.5f);
          check(load_w(t, 7, 200) == before && load_w(t, 200, 7) == 123.5f, "writing W[b][a] leaves W[a][b] untouched"); }
    }

    std::cout << "\n--- Resonance: spectrum decides dynamics (x <- Wx, normalised) ---\n";
    {
        auto R = randn_matrix(rng);
        struct Case { const char* name; float s, a; } cases[] = {
            {"symmetric    ", 1.f, 0.f}, {"antisymmetric ", 0.f, 1.f}, {"mixed 50/50   ", 1.f, 1.f}};
        Dyn d[3];
        for (int i = 0; i < 3; ++i) {
            Topology t; store_matrix(t, mix(R, cases[i].s, cases[i].a));
            d[i] = run_linear(load_matrix(t), rng, 600);
            std::printf("  %s <x_t,x_t+1> %+.3f   <x_t,x_t+2> %+.3f\n", cases[i].name, d[i].c1, d[i].c2);
        }
        check(d[0].c2 > 0.99, "symmetric: dominant real mode, x(t+2) == +x(t)");
        check(d[1].c2 < -0.9 && std::fabs(d[1].c1) < 0.1, "antisymmetric: dominant imaginary pair, quarter-turn rotation, x(t+2) == -x(t)");
        check(std::fabs(d[2].c2) < 0.99 && std::fabs(d[2].c1) < 0.99, "mixed: generic rotation angle (neither fixed nor quarter-turn)");
    }

    std::cout << "\n--- Sequence memory: asymmetric half stores A->B->C ---\n";
    {
        int cap_asym = 0, cap_sym_fail = 0;
        for (int P : {4, 8, 12, 16, 20, 24, 28, 32, 40, 48}) {
            float oa, os;
            int ga = sequence_recall(rng, P, true, &oa);
            int gs = sequence_recall(rng, P, false, &os);
            std::printf("  P=%2d  asymmetric exact steps %2d/%2d (overlap %.3f)   symmetric exact steps %2d/%2d (overlap %.3f)\n", P, ga, P, oa, gs, P, os);
            if (ga == P) cap_asym = P;
            if (P == 8 && gs < P) cap_sym_fail = 1;
        }
        std::printf("  largest P recalled perfectly (asymmetric, Hebbian, N=256): %d\n", cap_asym);
        check(cap_asym >= 12, "asymmetric stored cycle of >=12 patterns replays exactly");
        check(cap_sym_fail == 1, "symmetric storage cannot replay an ordered sequence");
    }

    std::cout << "\n========================================\nRound 18: " << pass << " passed, " << fail << " failed\n========================================\n";
    return fail ? 1 : 0;
}
